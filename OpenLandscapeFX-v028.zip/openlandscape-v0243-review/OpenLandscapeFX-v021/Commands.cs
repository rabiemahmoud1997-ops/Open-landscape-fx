using System;
using System.Collections.Generic;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.Runtime;

[assembly: CommandClass(typeof(OpenLandscapeFx.Commands))]

namespace OpenLandscapeFx
{
    public class Commands
    {
        private const string AppName = "OLF_PLANT_V2";
        private const string LabelAppName = "OLF_LABEL_V1";
        private const string ProjectKey = "OLF_PROJECT";

        [CommandMethod("OLFABOUT")]
        public void About()
        {
            ActiveEditor().WriteMessage("\nOpen Landscape FX 0.28 - Area/path distribution, safe updates, and catalog fixes.");
            ActiveEditor().WriteMessage("\nCommands: OLF, OLFABOUT, OLFNEWPROJECT, OLFPLANTMANAGER, OLFDELETEPLANT, OLFREPLACEPLANT, OLFUPDATE, OLFSETTINGS, OLFPLACEAREA, OLFAREAPREVIEW, OLFPLANTROW, OLFPLANTSCHEDULE, OLFLABELPLANTS, OLFPLANTDATA, OLFPLANTREPORT, OLFPLANTLEGEND, OLFQUICKTAKEOFF");
        }

        [CommandMethod("OLFPLANTREPORT")]
        public void PlantReport()
        {
            Database database = ActiveDocument().Database;
            Dictionary<string, int> counts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            Dictionary<string, int> categories = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            using (Transaction transaction = database.TransactionManager.StartTransaction())
            {
                BlockTableRecord modelSpace = (BlockTableRecord)transaction.GetObject(
                    SymbolUtilityServices.GetBlockModelSpaceId(database), OpenMode.ForRead);
                foreach (ObjectId id in modelSpace)
                {
                    BlockReference reference = transaction.GetObject(id, OpenMode.ForRead) as BlockReference;
                    if (reference == null) continue;
                    ResultBuffer data = reference.GetXDataForApplication(AppName);
                    if (data == null) continue;
                    string name = GetPlantName(data);
                    string category = GetPlantCategory(data);
                    if (!counts.ContainsKey(name)) counts[name] = 0;
                    if (!categories.ContainsKey(category)) categories[category] = 0;
                    counts[name]++; categories[category]++;
                    data.Dispose();
                }
                transaction.Commit();
            }
            Editor editor = ActiveEditor();
            editor.WriteMessage("\n--- Open Landscape FX Plant Report ---");
            editor.WriteMessage("\nTotal plant blocks: " + SumCounts(counts));
            foreach (KeyValuePair<string, int> pair in categories)
                editor.WriteMessage("\nCategory | " + pair.Key + " | " + pair.Value);
            foreach (KeyValuePair<string, int> pair in counts)
                editor.WriteMessage("\nPlant | " + pair.Key + " | " + pair.Value);
            editor.WriteMessage("\n--- End Plant Report ---");
        }

        private static int SumCounts(Dictionary<string, int> values)
        {
            int total = 0;
            foreach (int value in values.Values) total += value;
            return total;
        }

        [CommandMethod("OLFPLANTLEGEND")]
        public void PlantLegend()
        {
            Editor editor = ActiveEditor();
            PromptPointResult point = editor.GetPoint("\nSelect Plant Legend insertion point: ");
            if (point.Status != PromptStatus.OK) return;
            Database database = ActiveDocument().Database;
            Dictionary<string, Dictionary<string, PlantScheduleRecord>> groups = CollectScheduleGroups(database);
            if (groups.Count == 0)
            {
                editor.WriteMessage("\nNo OLF plants were found for the legend.");
                return;
            }
            OLFProjectSettings settings = ProjectSettingsStore.Load();
            using (Transaction transaction = database.TransactionManager.StartTransaction())
            {
                EnsureLayer(database, transaction, settings.ScheduleLayer);
                BlockTableRecord modelSpace = (BlockTableRecord)transaction.GetObject(
                    SymbolUtilityServices.GetBlockModelSpaceId(database), OpenMode.ForWrite);
                Point3d position = point.Value;
                foreach (KeyValuePair<string, Dictionary<string, PlantScheduleRecord>> group in groups)
                {
                    AppendScheduleTable(database, transaction, modelSpace, settings.ScheduleLayer,
                        "PLANT LEGEND - " + group.Key, group.Value, position);
                    position = position - new Vector3d(0, (group.Value.Count + 2) * 0.8 + 1.2, 0);
                }
                transaction.Commit();
            }
            editor.WriteMessage("\nPlant legend created from the current OLF plants.");
        }

        [CommandMethod("OLFQUICKTAKEOFF")]
        public void QuickTakeoff()
        {
            Editor editor = ActiveEditor();
            Dictionary<string, int> counts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            Database database = ActiveDocument().Database;
            using (Transaction transaction = database.TransactionManager.StartTransaction())
            {
                BlockTableRecord modelSpace = (BlockTableRecord)transaction.GetObject(
                    SymbolUtilityServices.GetBlockModelSpaceId(database), OpenMode.ForRead);
                foreach (ObjectId id in modelSpace)
                {
                    BlockReference reference = transaction.GetObject(id, OpenMode.ForRead) as BlockReference;
                    if (reference == null) continue;
                    ResultBuffer data = reference.GetXDataForApplication(AppName);
                    if (data == null) continue;
                    string code = GetPlantCode(data);
                    if (!counts.ContainsKey(code)) counts[code] = 0;
                    counts[code]++;
                    data.Dispose();
                }
                transaction.Commit();
            }
            if (counts.Count == 0)
            {
                editor.WriteMessage("\nNo OLF plants were found.");
                return;
            }
            using (System.Windows.Forms.SaveFileDialog dialog = new System.Windows.Forms.SaveFileDialog())
            {
                dialog.Filter = "CSV files|*.csv|All files|*.*";
                dialog.FileName = "olf-plant-takeoff.csv";
                if (dialog.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;
                using (System.IO.StreamWriter writer = new System.IO.StreamWriter(dialog.FileName, false, System.Text.Encoding.UTF8))
                {
                    writer.WriteLine("PlantCode,Quantity");
                    foreach (KeyValuePair<string, int> pair in counts)
                        writer.WriteLine(pair.Key + "," + pair.Value);
                }
                editor.WriteMessage("\nQuick takeoff exported to: " + dialog.FileName);
            }
        }

        [CommandMethod("OLF")]
        public void ToolPalette()
        {
            using (ToolPaletteForm form = new ToolPaletteForm())
            {
                if (Application.ShowModalDialog(form) != System.Windows.Forms.DialogResult.OK ||
                    String.IsNullOrEmpty(form.SelectedCommand))
                    return;
                ActiveDocument().SendStringToExecute(form.SelectedCommand + " ", true, false, false);
            }
        }

        [CommandMethod("OLFSETUPLAYERS")]
        public void SetupLayers()
        {
            Database database = ActiveDocument().Database;
            OLFProjectSettings settings = ProjectSettingsStore.Load();
            string[] layerNames = { settings.PlantLayer, settings.LabelLayer, settings.BoundaryLayer, settings.ScheduleLayer };
            using (Transaction transaction = database.TransactionManager.StartTransaction())
            {
                foreach (string layerName in layerNames)
                    EnsureLayer(database, transaction, layerName);
                transaction.Commit();
            }
            ActiveEditor().WriteMessage("\nOLF layers ready from project settings.");
        }

        [CommandMethod("OLFPLANTDATA")]
        public void PlantData()
        {
            using (PlantDataManagerForm form = new PlantDataManagerForm())
                Application.ShowModalDialog(form);
        }

        [CommandMethod("OLFSETTINGS")]
        public void ProjectSettings()
        {
            OLFProjectSettings settings = ProjectSettingsStore.Load();
            string oldPlantLayer = settings.PlantLayer;
            string oldLabelLayer = settings.LabelLayer;
            string oldScheduleLayer = settings.ScheduleLayer;
            string oldBoundaryLayer = settings.BoundaryLayer;
            using (ProjectSettingsForm form = new ProjectSettingsForm(settings))
                Application.ShowModalDialog(form);
            RenameConfiguredLayers(oldPlantLayer, settings.PlantLayer, oldLabelLayer, settings.LabelLayer,
                oldScheduleLayer, settings.ScheduleLayer, oldBoundaryLayer, settings.BoundaryLayer);
            ActiveEditor().WriteMessage("\nOLF project settings saved to: " + ProjectSettingsStore.FilePath);
        }

        private static void RenameConfiguredLayers(string oldPlant, string newPlant, string oldLabel, string newLabel,
            string oldSchedule, string newSchedule, string oldBoundary, string newBoundary)
        {
            Database database = ActiveDocument().Database;
            using (Transaction transaction = database.TransactionManager.StartTransaction())
            {
                RenameLayerIfNeeded(database, transaction, oldPlant, newPlant);
                RenameLayerIfNeeded(database, transaction, oldLabel, newLabel);
                RenameLayerIfNeeded(database, transaction, oldSchedule, newSchedule);
                RenameLayerIfNeeded(database, transaction, oldBoundary, newBoundary);
                transaction.Commit();
            }
        }

        private static void RenameLayerIfNeeded(Database database, Transaction transaction, string oldName, string newName)
        {
            if (String.IsNullOrWhiteSpace(oldName) || String.IsNullOrWhiteSpace(newName) ||
                oldName.Equals(newName, StringComparison.OrdinalIgnoreCase)) return;
            LayerTable table = (LayerTable)transaction.GetObject(database.LayerTableId, OpenMode.ForRead);
            if (!table.Has(oldName) || table.Has(newName)) return;
            LayerTableRecord layer = transaction.GetObject(table[oldName], OpenMode.ForWrite) as LayerTableRecord;
            if (layer != null) layer.Name = newName;
        }

        [CommandMethod("OLFDELETEPLANT")]
        public void DeletePlant()
        {
            Editor editor = ActiveEditor();
            PromptEntityOptions pick = new PromptEntityOptions("\nSelect a plant to delete: ");
            pick.SetRejectMessage("\nSelect an Open Landscape FX plant block.");
            pick.AddAllowedClass(typeof(BlockReference), true);
            PromptEntityResult picked = editor.GetEntity(pick);
            if (picked.Status != PromptStatus.OK) return;
            Database database = ActiveDocument().Database;
            string selectedName = string.Empty;
            using (Transaction transaction = database.TransactionManager.StartTransaction())
            {
                BlockReference reference = transaction.GetObject(picked.ObjectId, OpenMode.ForRead) as BlockReference;
                ResultBuffer data = reference == null ? null : reference.GetXDataForApplication(AppName);
                if (data == null) { editor.WriteMessage("\nThe selected block is not an OLF plant."); return; }
                selectedName = GetPlantName(data); data.Dispose();
                transaction.Commit();
            }
            PromptKeywordOptions scope = new PromptKeywordOptions("\nDelete [OnlySelected/AllSamePlant] <OnlySelected>: ");
            scope.AllowNone = true; scope.Keywords.Add("OnlySelected"); scope.Keywords.Add("AllSamePlant");
            PromptResult scopeResult = editor.GetKeywords(scope);
            if (scopeResult.Status != PromptStatus.OK && scopeResult.Status != PromptStatus.None) return;
            bool allSamePlant = scopeResult.Status == PromptStatus.OK && scopeResult.StringResult.Equals("AllSamePlant", StringComparison.OrdinalIgnoreCase);
            HashSet<string> handles = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            int deleted = 0;
            using (Transaction transaction = database.TransactionManager.StartTransaction())
            {
                BlockTableRecord modelSpace = (BlockTableRecord)transaction.GetObject(
                    SymbolUtilityServices.GetBlockModelSpaceId(database), OpenMode.ForWrite);
                foreach (ObjectId objectId in modelSpace)
                {
                    BlockReference reference = transaction.GetObject(objectId, OpenMode.ForWrite) as BlockReference;
                    if (reference == null) continue;
                    ResultBuffer data = reference.GetXDataForApplication(AppName);
                    if (data == null) continue;
                    bool matches = objectId == picked.ObjectId;
                    if (allSamePlant) matches = GetPlantName(data).Equals(selectedName, StringComparison.OrdinalIgnoreCase);
                    if (!matches) { data.Dispose(); continue; }
                    handles.Add(reference.ObjectId.Handle.ToString());
                    data.Dispose();
                    reference.Erase();
                    deleted++;
                }
                EraseLabelsForPlants(transaction, modelSpace, handles);
                transaction.Commit();
            }
            editor.WriteMessage("\nDeleted " + deleted + " plant(s) and their linked labels.");
        }

        [CommandMethod("OLFREPLACEPLANT")]
        public void ReplacePlant()
        {
            Editor editor = ActiveEditor();
            PromptEntityOptions options = new PromptEntityOptions("\nSelect one plant to replace: ");
            options.SetRejectMessage("\nSelect an Open Landscape FX plant block.");
            options.AddAllowedClass(typeof(BlockReference), true);
            PromptEntityResult selected = editor.GetEntity(options);
            if (selected.Status != PromptStatus.OK)
                return;

            Database database = ActiveDocument().Database;
            string selectedName = string.Empty;
            using (Transaction transaction = database.TransactionManager.StartTransaction())
            {
                BlockReference reference = transaction.GetObject(selected.ObjectId, OpenMode.ForRead) as BlockReference;
                if (reference == null || reference.GetXDataForApplication(AppName) == null)
                {
                    editor.WriteMessage("\nThe selected block is not an OLF plant.");
                    return;
                }
                ResultBuffer data = reference.GetXDataForApplication(AppName);
                selectedName = GetPlantName(data); data.Dispose();
                transaction.Commit();
            }

            PromptKeywordOptions scope = new PromptKeywordOptions("\nReplace [OnlySelected/AllSamePlant] <OnlySelected>: ");
            scope.AllowNone = true; scope.Keywords.Add("OnlySelected"); scope.Keywords.Add("AllSamePlant");
            PromptResult scopeResult = editor.GetKeywords(scope);
            if (scopeResult.Status != PromptStatus.OK && scopeResult.Status != PromptStatus.None) return;
            bool allSamePlant = scopeResult.Status == PromptStatus.OK && scopeResult.StringResult.Equals("AllSamePlant", StringComparison.OrdinalIgnoreCase);

            string plantName;
            string plantType;
            string plantCategory;
            string plantCode;
            double plantHeight;
            double plantSpread;
            double plantTrunkDiameter;
            using (PlantManagerForm form = new PlantManagerForm())
            {
                if (Application.ShowModalDialog(form) != System.Windows.Forms.DialogResult.OK)
                    return;
                plantName = form.PlantName;
                plantType = form.PlantType;
                plantCategory = form.PlantCategory;
                plantCode = form.PlantCode;
                plantHeight = form.PlantHeight;
                plantSpread = form.PlantSpread;
                plantTrunkDiameter = form.PlantTrunkDiameter;
            }

            int replaced = 0;
            using (Transaction transaction = database.TransactionManager.StartTransaction())
            {
                BlockTableRecord modelSpace = (BlockTableRecord)transaction.GetObject(
                    SymbolUtilityServices.GetBlockModelSpaceId(database), OpenMode.ForWrite);
                BlockTable blockTable = (BlockTable)transaction.GetObject(database.BlockTableId, OpenMode.ForRead);
                string blockName = GetBlockName(plantName, plantType);
                ObjectId blockId = blockTable.Has(blockName) ? blockTable[blockName] :
                    CreatePlantBlock(database, transaction, blockName, plantType, plantCategory, plantHeight, plantSpread, plantTrunkDiameter);
                HashSet<string> handles = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                foreach (ObjectId objectId in modelSpace)
                {
                    BlockReference reference = transaction.GetObject(objectId, OpenMode.ForWrite) as BlockReference;
                    if (reference == null) continue;
                    ResultBuffer data = reference.GetXDataForApplication(AppName);
                    if (data == null) continue;
                    bool matches = objectId == selected.ObjectId || (allSamePlant && GetPlantName(data).Equals(selectedName, StringComparison.OrdinalIgnoreCase));
                    data.Dispose();
                    if (!matches) continue;
                    handles.Add(reference.ObjectId.Handle.ToString());
                    reference.BlockTableRecord = blockId;
                    reference.XData = new ResultBuffer(
                        new TypedValue((int)DxfCode.ExtendedDataRegAppName, AppName),
                        new TypedValue((int)DxfCode.ExtendedDataAsciiString, plantName),
                        new TypedValue((int)DxfCode.ExtendedDataAsciiString, plantType),
                        new TypedValue((int)DxfCode.ExtendedDataAsciiString, plantCategory),
                        new TypedValue((int)DxfCode.ExtendedDataAsciiString, plantCode),
                        new TypedValue((int)DxfCode.ExtendedDataAsciiString, plantHeight.ToString(System.Globalization.CultureInfo.InvariantCulture)),
                        new TypedValue((int)DxfCode.ExtendedDataAsciiString, plantSpread.ToString(System.Globalization.CultureInfo.InvariantCulture)),
                        new TypedValue((int)DxfCode.ExtendedDataAsciiString, plantTrunkDiameter.ToString(System.Globalization.CultureInfo.InvariantCulture)));
                    replaced++;
                }
                EraseLabelsForPlants(transaction, modelSpace, handles);
                transaction.Commit();
            }
            UpdateExistingLabels();
            editor.WriteMessage("\nReplaced " + replaced + " plant(s) and updated existing linked labels only.");
        }

        [CommandMethod("OLFUPDATE")]
        public void UpdateOpenLandscape()
        {
            UpdateExistingSchedules();
            UpdateExistingLabels();
            ActiveEditor().WriteMessage("\nOLF update queued: labels and schedules rebuilt from current plant data.");
        }

        private static void UpdateExistingLabels()
        {
            Database database = ActiveDocument().Database;
            Dictionary<string, string> plantCodes = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            using (Transaction transaction = database.TransactionManager.StartTransaction())
            {
                BlockTableRecord modelSpace = (BlockTableRecord)transaction.GetObject(
                    SymbolUtilityServices.GetBlockModelSpaceId(database), OpenMode.ForRead);
                foreach (ObjectId id in modelSpace)
                {
                    BlockReference reference = transaction.GetObject(id, OpenMode.ForRead) as BlockReference;
                    if (reference == null) continue;
                    ResultBuffer data = reference.GetXDataForApplication(AppName);
                    if (data == null) continue;
                    plantCodes[reference.ObjectId.Handle.ToString()] = GetPlantCode(data);
                    data.Dispose();
                }
                BlockTableRecord writableSpace = (BlockTableRecord)transaction.GetObject(
                    SymbolUtilityServices.GetBlockModelSpaceId(database), OpenMode.ForWrite);
                foreach (ObjectId id in writableSpace)
                {
                    MLeader leader = transaction.GetObject(id, OpenMode.ForWrite) as MLeader;
                    if (leader == null) continue;
                    string target = GetLabelTargetHandle(leader);
                    string code;
                    if (String.IsNullOrEmpty(target) || !plantCodes.TryGetValue(target, out code)) continue;
                    MText content = leader.MText;
                    if (content == null) continue;
                    content.Contents = code;
                    leader.MText = content;
                }
                transaction.Commit();
            }
        }

        private static void UpdateExistingSchedules()
        {
            Database database = ActiveDocument().Database;
            OLFProjectSettings settings = ProjectSettingsStore.Load();
            Dictionary<string, Dictionary<string, PlantScheduleRecord>> groups = CollectScheduleGroups(database);
            if (groups.Count == 0) return;

            List<ObjectId> oldTableIds = new List<ObjectId>();
            List<Point3d> positions = new List<Point3d>();
            using (Transaction transaction = database.TransactionManager.StartTransaction())
            {
                BlockTableRecord modelSpace = (BlockTableRecord)transaction.GetObject(
                    SymbolUtilityServices.GetBlockModelSpaceId(database), OpenMode.ForRead);
                foreach (ObjectId id in modelSpace)
                {
                    Table table = transaction.GetObject(id, OpenMode.ForRead) as Table;
                    if (table == null || !table.Layer.Equals(settings.ScheduleLayer, StringComparison.OrdinalIgnoreCase)) continue;
                    oldTableIds.Add(id);
                    positions.Add(table.Position);
                }
                transaction.Commit();
            }
            if (positions.Count == 0) return;

            using (Transaction transaction = database.TransactionManager.StartTransaction())
            {
                EnsureLayer(database, transaction, settings.ScheduleLayer);
                BlockTableRecord modelSpace = (BlockTableRecord)transaction.GetObject(
                    SymbolUtilityServices.GetBlockModelSpaceId(database), OpenMode.ForWrite);
                int index = 0;
                Point3d nextExtraPosition = positions[positions.Count - 1];
                foreach (KeyValuePair<string, Dictionary<string, PlantScheduleRecord>> group in groups)
                {
                    Point3d position = index < positions.Count ? positions[index] :
                        nextExtraPosition - new Vector3d(0, (group.Value.Count + 2) * 0.8 + 1.2, 0);
                    AppendScheduleTable(database, transaction, modelSpace, settings.ScheduleLayer, group.Key, group.Value, position);
                    if (index >= positions.Count) nextExtraPosition = position;
                    index++;
                }
                foreach (ObjectId oldId in oldTableIds)
                {
                    Table oldTable = transaction.GetObject(oldId, OpenMode.ForWrite) as Table;
                    if (oldTable != null && !oldTable.IsErased) oldTable.Erase();
                }
                transaction.Commit();
            }
        }

        private static Dictionary<string, Dictionary<string, PlantScheduleRecord>> CollectScheduleGroups(Database database)
        {
            Dictionary<string, Dictionary<string, PlantScheduleRecord>> groups =
                new Dictionary<string, Dictionary<string, PlantScheduleRecord>>(StringComparer.OrdinalIgnoreCase);
            using (Transaction transaction = database.TransactionManager.StartTransaction())
            {
                BlockTableRecord modelSpace = (BlockTableRecord)transaction.GetObject(
                    SymbolUtilityServices.GetBlockModelSpaceId(database), OpenMode.ForRead);
                foreach (ObjectId id in modelSpace)
                {
                    BlockReference reference = transaction.GetObject(id, OpenMode.ForRead) as BlockReference;
                    if (reference == null) continue;
                    ResultBuffer data = reference.GetXDataForApplication(AppName);
                    if (data == null) continue;
                    string code = GetPlantCode(data);
                    string category = GetPlantCategory(data);
                    string name = GetPlantName(data);
                    if (code != "UNK" && name.Length > 0)
                    {
                        Dictionary<string, PlantScheduleRecord> categoryRecords;
                        if (!groups.TryGetValue(category, out categoryRecords))
                        {
                            categoryRecords = new Dictionary<string, PlantScheduleRecord>(StringComparer.OrdinalIgnoreCase);
                            groups[category] = categoryRecords;
                        }
                        PlantScheduleRecord record;
                        if (!categoryRecords.TryGetValue(code, out record))
                        {
                            record = new PlantScheduleRecord(name, GetPlantScientific(data), GetPlantNumber(data, 4, 1),
                                GetPlantNumber(data, 5, 1), GetPlantNumber(data, 6, 0), 0);
                            categoryRecords[code] = record;
                        }
                        record.Quantity++;
                    }
                    data.Dispose();
                }
                transaction.Commit();
            }
            return groups;
        }

        private static void AppendScheduleTable(Database database, Transaction transaction,
            BlockTableRecord modelSpace, string layerName, string category,
            Dictionary<string, PlantScheduleRecord> records, Point3d position)
        {
            Table table = new Table();
            table.TableStyle = database.Tablestyle;
            table.Layer = layerName;
            table.SetSize(records.Count + 2, 9);
            table.Position = position;
            table.SetRowHeight(0.8);
            for (int col = 0; col < 9; col++) table.SetColumnWidth(col, col == 0 ? 2.2 : 2.4);
            table.SetTextString(0, 0, category);
            string[] headers = { "Symbol", "Code", "Scientific name", "Common name", "Height", "Spread", "Trunk", "Quantity", "Unit" };
            for (int col = 0; col < headers.Length; col++) table.SetTextString(1, col, headers[col]);
            int row = 2;
            foreach (KeyValuePair<string, PlantScheduleRecord> pair in records)
            {
                PlantScheduleRecord item = pair.Value;
                ObjectId symbolBlock = FindPlantBlock(database, transaction, item.CommonName);
                if (!symbolBlock.IsNull)
                {
                    table.SetBlockTableRecordId(row, 0, symbolBlock, false);
                    table.SetBlockScale(row, 0, 0.28);
                }
                else table.SetTextString(row, 0, MakePlantSymbol(item.CommonName));
                table.SetTextString(row, 1, pair.Key);
                table.SetTextString(row, 2, item.ScientificName);
                table.SetTextString(row, 3, item.CommonName);
                table.SetTextString(row, 4, item.Height.ToString("0.##"));
                table.SetTextString(row, 5, item.Spread.ToString("0.##"));
                table.SetTextString(row, 6, item.Trunk.ToString("0.##"));
                table.SetTextString(row, 7, item.Quantity.ToString());
                table.SetTextString(row, 8, "EA");
                row++;
            }
            for (int r = 0; r < records.Count + 2; r++)
                for (int c = 0; c < 9; c++) table.SetAlignment(r, c, CellAlignment.MiddleCenter);
            modelSpace.AppendEntity(table);
            transaction.AddNewlyCreatedDBObject(table, true);
        }

        [CommandMethod("OLFEDITPLANT")]
        public void EditPlant()
        {
            Editor editor = ActiveEditor();
            PromptEntityOptions options = new PromptEntityOptions("\nSelect one OLF plant to edit: ");
            options.SetRejectMessage("\nSelect an Open Landscape FX plant block.");
            options.AddAllowedClass(typeof(BlockReference), true);
            PromptEntityResult selected = editor.GetEntity(options);
            if (selected.Status != PromptStatus.OK) return;

            Database database = ActiveDocument().Database;
            BlockReference original;
            string oldHandle;
            using (Transaction transaction = database.TransactionManager.StartTransaction())
            {
                original = transaction.GetObject(selected.ObjectId, OpenMode.ForRead) as BlockReference;
                if (original == null || original.GetXDataForApplication(AppName) == null)
                {
                    editor.WriteMessage("\nThe selected object is not an OLF plant.");
                    return;
                }
                oldHandle = original.ObjectId.Handle.ToString();
                transaction.Commit();
            }

            string plantName, plantType, plantCategory, plantCode;
            double height, spread, trunk;
            using (PlantManagerForm form = new PlantManagerForm())
            {
                if (Application.ShowModalDialog(form) != System.Windows.Forms.DialogResult.OK) return;
                plantName = form.PlantName; plantType = form.PlantType; plantCategory = form.PlantCategory;
                plantCode = form.PlantCode; height = form.PlantHeight; spread = form.PlantSpread; trunk = form.PlantTrunkDiameter;
            }

            using (Transaction transaction = database.TransactionManager.StartTransaction())
            {
                BlockReference reference = transaction.GetObject(selected.ObjectId, OpenMode.ForWrite) as BlockReference;
                if (reference == null) return;
                BlockTable blockTable = (BlockTable)transaction.GetObject(database.BlockTableId, OpenMode.ForRead);
                string blockName = GetBlockName(plantName, plantType);
                ObjectId blockId = blockTable.Has(blockName) ? blockTable[blockName] :
                    CreatePlantBlock(database, transaction, blockName, plantType, plantCategory, height, spread, trunk);
                reference.BlockTableRecord = blockId;
                SetPlantXData(reference, database, transaction, plantName, plantType, plantCategory, plantCode, height, spread, trunk);
                BlockTableRecord modelSpace = (BlockTableRecord)transaction.GetObject(
                    SymbolUtilityServices.GetBlockModelSpaceId(database), OpenMode.ForWrite);
                EraseLabelsForPlants(transaction, modelSpace,
                    new HashSet<string>(new[] { oldHandle }, StringComparer.OrdinalIgnoreCase));
                transaction.Commit();
            }
            editor.WriteMessage("\nPlant edited in place. Handle and drawing Scale were preserved.");
            UpdateExistingLabels();
        }

        [CommandMethod("OLFNEWPROJECT")]
        public void NewProject()
        {
            Database database = ActiveDocument().Database;
            using (Transaction transaction = database.TransactionManager.StartTransaction())
            {
                DBDictionary namedObjects = (DBDictionary)transaction.GetObject(
                    database.NamedObjectsDictionaryId, OpenMode.ForWrite);
                if (!namedObjects.Contains(ProjectKey))
                {
                    Xrecord project = new Xrecord();
                    project.Data = new ResultBuffer(
                        new TypedValue((int)DxfCode.Text, "Open Landscape FX"),
                        new TypedValue((int)DxfCode.Text, DateTime.UtcNow.ToString("O")),
                        new TypedValue((int)DxfCode.Text, "metric"));
                    namedObjects.SetAt(ProjectKey, project);
                    transaction.AddNewlyCreatedDBObject(project, true);
                }
                EnsureRegApp(database, transaction, AppName);
                transaction.Commit();
            }
            ActiveEditor().WriteMessage("\nOLF project initialized in this drawing.");
        }

        [CommandMethod("OLFADDPLANT")]
        public void AddPlant()
        {
            Editor editor = ActiveEditor();
            PromptStringOptions plantPrompt = new PromptStringOptions("\nPlant name <Lavender>: ");
            plantPrompt.AllowSpaces = true;
            plantPrompt.UseDefaultValue = true;
            plantPrompt.DefaultValue = "Lavender";
            PromptResult plantResult = editor.GetString(plantPrompt);
            if (plantResult.Status != PromptStatus.OK)
                return;

            PromptKeywordOptions typePrompt = new PromptKeywordOptions("\nPlant type [Tree/Shrub/Grass/Groundcover] <Shrub>: ");
            typePrompt.AllowNone = true;
            typePrompt.Keywords.Add("Tree");
            typePrompt.Keywords.Add("Shrub");
            typePrompt.Keywords.Add("Grass");
            typePrompt.Keywords.Add("Groundcover");
            PromptResult typeResult = editor.GetKeywords(typePrompt);
            if (typeResult.Status != PromptStatus.OK && typeResult.Status != PromptStatus.None)
                return;
            string plantType = typeResult.Status == PromptStatus.None ? "Shrub" : typeResult.StringResult;

            PromptPointResult pointResult = editor.GetPoint("\nSelect plant insertion point: ");
            if (pointResult.Status != PromptStatus.OK)
                return;

            Database database = ActiveDocument().Database;
            using (Transaction transaction = database.TransactionManager.StartTransaction())
            {
                EnsureRegApp(database, transaction, AppName);
                string blockName = GetBlockName(plantResult.StringResult, plantType);
                BlockTable blockTable = (BlockTable)transaction.GetObject(database.BlockTableId, OpenMode.ForRead);
                ObjectId blockId;
                if (!blockTable.Has(blockName))
                    blockId = CreatePlantBlock(database, transaction, blockName, plantType, "Small Shrub", 1.2, 1.0, 0.05);
                else
                    blockId = blockTable[blockName];

                BlockTableRecord modelSpace = (BlockTableRecord)transaction.GetObject(
                    SymbolUtilityServices.GetBlockModelSpaceId(database), OpenMode.ForWrite);
                BlockReference reference = new BlockReference(pointResult.Value, blockId);
                modelSpace.AppendEntity(reference);
                transaction.AddNewlyCreatedDBObject(reference, true);
                reference.XData = new ResultBuffer(
                    new TypedValue((int)DxfCode.ExtendedDataRegAppName, AppName),
                    new TypedValue((int)DxfCode.ExtendedDataAsciiString, plantResult.StringResult),
                    new TypedValue((int)DxfCode.ExtendedDataAsciiString, plantType),
                    new TypedValue((int)DxfCode.ExtendedDataAsciiString, "Small Shrub"),
                    new TypedValue((int)DxfCode.ExtendedDataAsciiString, "1.2"),
                    new TypedValue((int)DxfCode.ExtendedDataAsciiString, "1.0"),
                    new TypedValue((int)DxfCode.ExtendedDataAsciiString, "0.05"));
                transaction.Commit();
            }
            editor.WriteMessage("\nPlaced " + plantType + " block: " + plantResult.StringResult);
        }

        [CommandMethod("OLFPLANTMANAGER")]
        public void PlantManager()
        {
            while (true)
            {
                string plantName;
                string plantType;
                string plantCategory;
                string plantCode;
                double plantHeight;
                double plantSpread;
                double plantTrunkDiameter;
                using (PlantManagerForm form = new PlantManagerForm())
                {
                    if (Application.ShowModalDialog(form) != System.Windows.Forms.DialogResult.OK)
                        return;
                    plantName = form.PlantName;
                    plantType = form.PlantType;
                    plantCategory = form.PlantCategory;
                    plantCode = form.PlantCode;
                    plantHeight = form.PlantHeight;
                    plantSpread = form.PlantSpread;
                    plantTrunkDiameter = form.PlantTrunkDiameter;
                }

                ActiveEditor().WriteMessage("\nClick points for " + plantName + ". Press Enter to choose another plant.");
                while (true)
                {
                    PromptPointResult pointResult = ActiveEditor().GetPoint("\nPlant point <Enter = manager>: ");
                    if (pointResult.Status != PromptStatus.OK)
                        break;
                    PlacePlantBlock(plantName, plantType, plantCategory, plantCode, plantHeight,
                        plantSpread, plantTrunkDiameter, pointResult.Value);
                    ActiveEditor().WriteMessage("\nPlaced " + plantType + " block: " + plantName);
                }
            }
        }

        [CommandMethod("OLFPLACEBOUNDARY")]
        public void PlaceBoundary()
        {
            Editor editor = ActiveEditor();
            PromptEntityOptions boundaryPrompt = new PromptEntityOptions(
                "\nSelect a closed Polyline boundary (or one whose last point snaps to its first): ");
            boundaryPrompt.SetRejectMessage("\nPlease select a 2D Polyline.");
            boundaryPrompt.AddAllowedClass(typeof(Polyline), true);
            PromptEntityResult boundaryResult = editor.GetEntity(boundaryPrompt);
            if (boundaryResult.Status != PromptStatus.OK)
                return;

            Database database = ActiveDocument().Database;
            Point2d[] boundaryPoints;
            Extents3d extents;
            using (Transaction transaction = database.TransactionManager.StartTransaction())
            {
                Polyline boundary = transaction.GetObject(boundaryResult.ObjectId, OpenMode.ForRead) as Polyline;
                if (boundary == null || boundary.NumberOfVertices < 3)
                {
                    editor.WriteMessage("\nThe selected Polyline must have at least three vertices.");
                    return;
                }

                Point2d firstPoint = boundary.GetPoint2dAt(0);
                Point2d lastPoint = boundary.GetPoint2dAt(boundary.NumberOfVertices - 1);
                bool endpointClosed = firstPoint.GetDistanceTo(lastPoint) <= 0.000001;
                if (!boundary.Closed && !endpointClosed)
                {
                    editor.WriteMessage("\nThe Polyline must be closed, or its last point must coincide with its first point.");
                    return;
                }

                boundaryPoints = TessellatePolyline(boundary, endpointClosed);
                extents = boundary.GeometricExtents;
                transaction.Commit();
            }

            string plantName;
            string plantType;
            string plantCategory;
            string plantCode;
            double plantHeight;
            double plantSpread;
            double plantTrunkDiameter;
            using (PlantManagerForm form = new PlantManagerForm())
            {
                if (Application.ShowModalDialog(form) != System.Windows.Forms.DialogResult.OK)
                    return;
                plantName = form.PlantName;
                plantType = form.PlantType;
                plantCategory = form.PlantCategory;
                plantCode = form.PlantCode;
                plantHeight = form.PlantHeight;
                plantSpread = form.PlantSpread;
                plantTrunkDiameter = form.PlantTrunkDiameter;
            }

            double horizontalSpacing;
            double verticalSpacing;
            if (!ReadSpacing(editor, out horizontalSpacing, out verticalSpacing))
                return;

            int placed = 0;
            List<Point3d> candidatePoints = new List<Point3d>();
            double z = extents.MinPoint.Z;
            foreach (double x in BuildAxisSamples(extents.MinPoint.X, extents.MaxPoint.X, horizontalSpacing))
            {
                foreach (double y in BuildAxisSamples(extents.MinPoint.Y, extents.MaxPoint.Y, verticalSpacing))
                {
                    if (!IsPointInsidePolyline(boundaryPoints, x, y))
                        continue;
                    if (!IsFarEnoughFromBoundary(boundaryPoints, x, y,
                        horizontalSpacing, verticalSpacing))
                        continue;
                    candidatePoints.Add(new Point3d(x, y, z));
                }
            }
            double uniformScale = CalculateUniformPlantScale(candidatePoints, plantSpread);
            foreach (Point3d candidate in candidatePoints)
            {
                PlacePlantBlock(plantName, plantType, plantCategory, plantCode, plantHeight, plantSpread, plantTrunkDiameter, candidate, uniformScale);
                placed++;
            }
            editor.WriteMessage("\nPlaced " + placed + " plants inside the selected boundary. Uniform plant scale: " + uniformScale.ToString("0.###"));
        }

        [CommandMethod("OLFPLANTROW")]
        public void PlantRow()
        {
            Editor editor = ActiveEditor();
            PromptPointResult first = editor.GetPoint("\nPick first row point: ");
            if (first.Status != PromptStatus.OK) return;
            PromptPointOptions secondOptions = new PromptPointOptions("\nPick second row point: ");
            secondOptions.UseBasePoint = true;
            secondOptions.BasePoint = first.Value;
            PromptPointResult second = editor.GetPoint(secondOptions);
            if (second.Status != PromptStatus.OK) return;
            PromptDoubleOptions spacingPrompt = new PromptDoubleOptions("\nRow spacing <2.0>: ")
            { AllowNone = true, DefaultValue = 2.0, AllowZero = false, AllowNegative = false };
            PromptDoubleResult spacingResult = editor.GetDouble(spacingPrompt);
            if (spacingResult.Status != PromptStatus.OK && spacingResult.Status != PromptStatus.None) return;
            double spacing = spacingResult.Status == PromptStatus.None ? 2.0 : spacingResult.Value;
            string plantName, plantType, plantCategory, plantCode;
            double height, spread, trunk;
            using (PlantManagerForm form = new PlantManagerForm())
            {
                if (Application.ShowModalDialog(form) != System.Windows.Forms.DialogResult.OK) return;
                plantName = form.PlantName; plantType = form.PlantType; plantCategory = form.PlantCategory;
                plantCode = form.PlantCode; height = form.PlantHeight; spread = form.PlantSpread; trunk = form.PlantTrunkDiameter;
            }
            Vector3d direction = second.Value - first.Value;
            double length = direction.Length;
            if (length <= 0.000001) return;
            Vector3d unit = direction / length;
            int count = Math.Max(1, (int)Math.Floor(length / spacing) + 1);
            for (int i = 0; i < count; i++)
            {
                Point3d point = first.Value + unit * (i * spacing);
                PlacePlantBlock(plantName, plantType, plantCategory, plantCode, height, spread, trunk, point);
            }
            editor.WriteMessage("\nPlaced " + count + " plants along the row at exact spacing " + spacing.ToString("0.###") + ".");
        }

        [CommandMethod("OLFPLANTPATH")]
        public void PlantPath()
        {
            Editor editor = ActiveEditor();
            PromptEntityOptions pathPrompt = new PromptEntityOptions("\nSelect a Polyline path: ");
            pathPrompt.SetRejectMessage("\nSelect a 2D Polyline.");
            pathPrompt.AddAllowedClass(typeof(Polyline), true);
            PromptEntityResult pathResult = editor.GetEntity(pathPrompt);
            if (pathResult.Status != PromptStatus.OK) return;
            Database database = ActiveDocument().Database;
            double pathLength;
            using (Transaction transaction = database.TransactionManager.StartTransaction())
            {
                Polyline path = transaction.GetObject(pathResult.ObjectId, OpenMode.ForRead) as Polyline;
                if (path == null || path.NumberOfVertices < 2) return;
                pathLength = path.Length;
                transaction.Commit();
            }
            PromptPointResult startPick = editor.GetPoint("\nPick start point on path: ");
            if (startPick.Status != PromptStatus.OK) return;
            PromptPointOptions endOptions = new PromptPointOptions("\nPick end point on path: ");
            endOptions.UseBasePoint = true; endOptions.BasePoint = startPick.Value;
            PromptPointResult endPick = editor.GetPoint(endOptions);
            if (endPick.Status != PromptStatus.OK) return;
            double startDistance, endDistance;
            if (!GetPathDistance(database, pathResult.ObjectId, startPick.Value, out startDistance) ||
                !GetPathDistance(database, pathResult.ObjectId, endPick.Value, out endDistance)) return;
            if (endDistance < startDistance)
            {
                double swap = startDistance; startDistance = endDistance; endDistance = swap;
            }
            PromptDoubleOptions spacingPrompt = new PromptDoubleOptions("\nPlant spacing along path <2.0>: ")
            { AllowNone = true, DefaultValue = 2.0, AllowZero = false, AllowNegative = false };
            PromptDoubleResult spacingResult = editor.GetDouble(spacingPrompt);
            if (spacingResult.Status != PromptStatus.OK && spacingResult.Status != PromptStatus.None) return;
            double spacing = spacingResult.Status == PromptStatus.None ? 2.0 : spacingResult.Value;
            double offset;
            if (!ReadOptionalDistance(editor, "\nOffset from path <0.0>: ", 0.0, out offset)) return;
            PromptKeywordOptions rotationPrompt = new PromptKeywordOptions("\nRotation [Follow/Fixed] <Follow>: ");
            rotationPrompt.AllowNone = true; rotationPrompt.Keywords.Add("Follow"); rotationPrompt.Keywords.Add("Fixed");
            PromptResult rotationResult = editor.GetKeywords(rotationPrompt);
            if (rotationResult.Status != PromptStatus.OK && rotationResult.Status != PromptStatus.None) return;
            bool followRotation = rotationResult.Status != PromptStatus.OK || rotationResult.StringResult.Equals("Follow", StringComparison.OrdinalIgnoreCase);
            double fixedRotation = 0.0;
            if (!followRotation && !ReadOptionalDistance(editor, "\nFixed rotation in degrees <0>: ", 0.0, out fixedRotation)) return;
            string plantName, plantType, plantCategory, plantCode;
            double height, spread, trunk;
            using (PlantManagerForm form = new PlantManagerForm())
            {
                if (Application.ShowModalDialog(form) != System.Windows.Forms.DialogResult.OK) return;
                plantName = form.PlantName; plantType = form.PlantType; plantCategory = form.PlantCategory;
                plantCode = form.PlantCode; height = form.PlantHeight; spread = form.PlantSpread; trunk = form.PlantTrunkDiameter;
            }
            int count = Math.Max(1, (int)Math.Floor((endDistance - startDistance) / spacing) + 1);
            List<Point3d> pathPoints = new List<Point3d>();
            List<double> pathAngles = new List<double>();
            for (int i = 0; i < count; i++)
            {
                double distance = startDistance + i * spacing;
                if (distance > endDistance + 0.000001) break;
                Point3d point; double angle;
                if (!GetPathPlacement(database, pathResult.ObjectId, distance, offset, out point, out angle)) continue;
                pathPoints.Add(point); pathAngles.Add(angle);
            }
            double uniformScale = CalculateUniformPlantScale(pathPoints, spread);
            for (int i = 0; i < pathPoints.Count; i++)
                PlacePlantBlock(plantName, plantType, plantCategory, plantCode, height, spread, trunk, pathPoints[i], uniformScale,
                    followRotation ? pathAngles[i] : fixedRotation);
            editor.WriteMessage("\nPlaced " + pathPoints.Count + " plants on path at spacing " + spacing.ToString("0.###") + ", offset " + offset.ToString("0.###") + ". Uniform scale=" + uniformScale.ToString("0.###") + ", Rotation=" + (followRotation ? "Follow" : "Fixed"));
        }

        private static bool GetPathDistance(Database database, ObjectId pathId, Point3d pick, out double distance)
        {
            distance = 0.0;
            using (Transaction transaction = database.TransactionManager.StartTransaction())
            {
                Polyline path = transaction.GetObject(pathId, OpenMode.ForRead) as Polyline;
                if (path == null) return false;
                Point3d closest = path.GetClosestPointTo(pick, false);
                distance = path.GetDistAtPoint(closest);
                transaction.Commit();
            }
            return true;
        }

        private static bool GetPathPlacement(Database database, ObjectId pathId, double distance, double offset,
            out Point3d point, out double angle)
        {
            point = Point3d.Origin; angle = 0.0;
            using (Transaction transaction = database.TransactionManager.StartTransaction())
            {
                Polyline path = transaction.GetObject(pathId, OpenMode.ForRead) as Polyline;
                if (path == null || distance < 0.0 || distance > path.Length) return false;
                Point3d center = path.GetPointAtDist(distance);
                double delta = Math.Min(0.01, Math.Max(0.0001, path.Length * 0.0001));
                Point3d before = path.GetPointAtDist(Math.Max(0.0, distance - delta));
                Point3d after = path.GetPointAtDist(Math.Min(path.Length, distance + delta));
                Vector3d tangent = after - before;
                if (tangent.Length <= 0.000001) return false;
                tangent = tangent.GetNormal();
                Vector3d normal = new Vector3d(-tangent.Y, tangent.X, 0).GetNormal();
                point = center + normal * offset;
                angle = Math.Atan2(tangent.Y, tangent.X) * 180.0 / Math.PI;
                transaction.Commit();
            }
            return true;
        }

        [CommandMethod("OLFPLACEAREA")]
        public void PlaceArea()
        {
            Editor editor = ActiveEditor();
            PromptKeywordOptions mode = new PromptKeywordOptions("\nArea method [Select/PickInside] <Select>: ");
            mode.AllowNone = true;
            mode.Keywords.Add("Select");
            mode.Keywords.Add("PickInside");
            PromptResult modeResult = editor.GetKeywords(mode);
            if (modeResult.Status != PromptStatus.OK && modeResult.Status != PromptStatus.None) return;
            bool pickInside = modeResult.Status == PromptStatus.OK &&
                modeResult.StringResult.Equals("PickInside", StringComparison.OrdinalIgnoreCase);

            Database database = ActiveDocument().Database;
            ObjectId boundaryId = ObjectId.Null;
            Point3d pickPoint = Point3d.Origin;
            if (pickInside)
            {
                PromptPointResult point = editor.GetPoint("\nPick a point inside a closed area: ");
                if (point.Status != PromptStatus.OK) return;
                pickPoint = point.Value;
                using (Transaction transaction = database.TransactionManager.StartTransaction())
                {
                    BlockTableRecord modelSpace = (BlockTableRecord)transaction.GetObject(
                        SymbolUtilityServices.GetBlockModelSpaceId(database), OpenMode.ForRead);
                    foreach (ObjectId id in modelSpace)
                    {
                        Polyline candidate = transaction.GetObject(id, OpenMode.ForRead) as Polyline;
                        if (candidate == null || candidate.NumberOfVertices < 3 || !candidate.Closed) continue;
                        Point2d[] points = TessellatePolyline(candidate, false);
                        if (IsPointInsidePolyline(points, pickPoint.X, pickPoint.Y))
                        {
                            boundaryId = id;
                            break;
                        }
                    }
                    transaction.Commit();
                }
                if (boundaryId.IsNull)
                {
                    editor.WriteMessage("\nNo closed Polyline contains the picked point.");
                    return;
                }
            }
            else
            {
                PromptEntityOptions prompt = new PromptEntityOptions("\nSelect a closed Polyline area: ");
                prompt.SetRejectMessage("\nPlease select a closed 2D Polyline.");
                prompt.AddAllowedClass(typeof(Polyline), true);
                PromptEntityResult selected = editor.GetEntity(prompt);
                if (selected.Status != PromptStatus.OK) return;
                boundaryId = selected.ObjectId;
            }

            Point2d[] boundaryPoints;
            Extents3d extents;
            using (Transaction transaction = database.TransactionManager.StartTransaction())
            {
                Polyline boundary = transaction.GetObject(boundaryId, OpenMode.ForRead) as Polyline;
                if (boundary == null || boundary.NumberOfVertices < 3 || !boundary.Closed)
                {
                    editor.WriteMessage("\nThe area must be a closed Polyline.");
                    return;
                }
                boundaryPoints = TessellatePolyline(boundary, false);
                extents = boundary.GeometricExtents;
                transaction.Commit();
            }
            string plantName, plantType, plantCategory, plantCode;
            double plantHeight, plantSpread, plantTrunkDiameter;
            using (PlantManagerForm form = new PlantManagerForm())
            {
                if (Application.ShowModalDialog(form) != System.Windows.Forms.DialogResult.OK) return;
                plantName = form.PlantName; plantType = form.PlantType; plantCategory = form.PlantCategory;
                plantCode = form.PlantCode; plantHeight = form.PlantHeight; plantSpread = form.PlantSpread;
                plantTrunkDiameter = form.PlantTrunkDiameter;
            }
            double horizontalSpacing, verticalSpacing;
            if (!ReadSpacing(editor, out horizontalSpacing, out verticalSpacing)) return;
            PromptPointResult startPointResult = editor.GetPoint("\nPick distribution start point <Enter = area center>: ");
            Point2d distributionStart = startPointResult.Status == PromptStatus.OK
                ? new Point2d(startPointResult.Value.X, startPointResult.Value.Y)
                : new Point2d((extents.MinPoint.X + extents.MaxPoint.X) * 0.5, (extents.MinPoint.Y + extents.MaxPoint.Y) * 0.5);
            PromptKeywordOptions angleMode = new PromptKeywordOptions("\nAngle source [Number/Mouse/Entity] <Mouse>: ");
            angleMode.AllowNone = true; angleMode.Keywords.Add("Number"); angleMode.Keywords.Add("Mouse"); angleMode.Keywords.Add("Entity");
            PromptResult angleModeResult = editor.GetKeywords(angleMode);
            if (angleModeResult.Status != PromptStatus.OK && angleModeResult.Status != PromptStatus.None) return;
            string angleSource = angleModeResult.Status == PromptStatus.None ? "Mouse" : angleModeResult.StringResult;
            double rotation = 0.0;
            if (angleSource.Equals("Number", StringComparison.OrdinalIgnoreCase))
            {
                if (!ReadOptionalDistance(editor, "\nRow rotation in degrees <0>: ", 0.0, out rotation)) return;
            }
            else if (angleSource.Equals("Entity", StringComparison.OrdinalIgnoreCase))
            {
                PromptEntityOptions entityPrompt = new PromptEntityOptions("\nSelect a line or polyline for its angle: ");
                entityPrompt.SetRejectMessage("\nSelect a Line or Polyline.");
                entityPrompt.AddAllowedClass(typeof(Line), true); entityPrompt.AddAllowedClass(typeof(Polyline), true);
                PromptEntityResult entityResult = editor.GetEntity(entityPrompt);
                if (entityResult.Status != PromptStatus.OK) return;
                rotation = GetEntityAngle(database, entityResult.ObjectId);
            }
            else
            {
                PromptPointOptions anglePointPrompt = new PromptPointOptions("\nPick direction point: ");
                anglePointPrompt.UseBasePoint = true; anglePointPrompt.BasePoint = new Point3d(distributionStart.X, distributionStart.Y, extents.MinPoint.Z);
                PromptPointResult anglePoint = editor.GetPoint(anglePointPrompt);
                if (anglePoint.Status != PromptStatus.OK) return;
                rotation = Math.Atan2(anglePoint.Value.Y - distributionStart.Y, anglePoint.Value.X - distributionStart.X) * 180.0 / Math.PI;
            }
            PromptKeywordOptions patternPrompt = new PromptKeywordOptions("\nPattern [Grid/Staggered] <Grid>: ");
            patternPrompt.AllowNone = true; patternPrompt.Keywords.Add("Grid"); patternPrompt.Keywords.Add("Staggered");
            PromptResult patternResult = editor.GetKeywords(patternPrompt);
            if (patternResult.Status != PromptStatus.OK && patternResult.Status != PromptStatus.None) return;
            bool staggered = patternResult.Status == PromptStatus.OK && patternResult.StringResult.Equals("Staggered", StringComparison.OrdinalIgnoreCase);
            double margin;
            if (!ReadOptionalDistance(editor, "\nBoundary margin <0.0>: ", 0.0, out margin)) return;
            PlacePlantsInArea(editor, boundaryPoints, extents, plantName, plantType, plantCategory, plantCode,
                plantHeight, plantSpread, plantTrunkDiameter, horizontalSpacing, verticalSpacing, staggered, margin, rotation, distributionStart);
        }

        [CommandMethod("OLFAREAPREVIEW")]
        public void AreaPreview()
        {
            Editor editor = ActiveEditor();
            PromptEntityOptions prompt = new PromptEntityOptions("\nSelect a closed Polyline to preview distribution: ");
            prompt.SetRejectMessage("\nSelect a closed 2D Polyline."); prompt.AddAllowedClass(typeof(Polyline), true);
            PromptEntityResult selected = editor.GetEntity(prompt);
            if (selected.Status != PromptStatus.OK) return;
            Database database = ActiveDocument().Database;
            Point2d[] points; Extents3d extents;
            using (Transaction transaction = database.TransactionManager.StartTransaction())
            {
                Polyline boundary = transaction.GetObject(selected.ObjectId, OpenMode.ForRead) as Polyline;
                if (boundary == null || !boundary.Closed || boundary.NumberOfVertices < 3) return;
                points = TessellatePolyline(boundary, false); extents = boundary.GeometricExtents; transaction.Commit();
            }
            double h, v;
            if (!ReadSpacing(editor, out h, out v)) return;
            int total = 0;
            foreach (double x in BuildAxisSamples(extents.MinPoint.X, extents.MaxPoint.X, h))
                foreach (double y in BuildAxisSamples(extents.MinPoint.Y, extents.MaxPoint.Y, v))
                    if (IsPointInsidePolyline(points, x, y)) total++;
            editor.WriteMessage("\nArea preview: approximately " + total + " planting locations at H=" + h.ToString("0.###") + " V=" + v.ToString("0.###") + ". No plants were added.");
        }

        private static void PlacePlantsInArea(Editor editor, Point2d[] boundaryPoints, Extents3d extents,
            string plantName, string plantType, string plantCategory, string plantCode, double plantHeight,
            double plantSpread, double plantTrunkDiameter, double horizontalSpacing, double verticalSpacing,
            bool staggered, double margin, double rotationDegrees, Point2d distributionStart)
        {
            List<Point3d> candidatePoints = new List<Point3d>();
            double z = extents.MinPoint.Z;
            // The insertion/start pick is an orientation reference only; anchoring the grid
            // at it can shift half of a rectangle outside the boundary. Always center the
            // sampling grid on the actual boundary extents so the complete area is covered.
            Point2d center = new Point2d((extents.MinPoint.X + extents.MaxPoint.X) * 0.5,
                (extents.MinPoint.Y + extents.MaxPoint.Y) * 0.5);
            double angle = rotationDegrees * Math.PI / 180.0;
            double cos = Math.Cos(angle), sin = Math.Sin(angle);
            double minX = -(extents.MaxPoint.X - extents.MinPoint.X) * 0.5;
            double maxX = -minX, minY = -(extents.MaxPoint.Y - extents.MinPoint.Y) * 0.5, maxY = -minY;
            int row = 0;
            foreach (double localY in BuildAxisSamples(minY, maxY, verticalSpacing))
            {
                double offset = staggered && row % 2 == 1 ? horizontalSpacing * 0.5 : 0.0;
                foreach (double baseX in BuildAxisSamples(minX, maxX, horizontalSpacing))
                {
                    double localX = baseX + offset;
                {
                    double x = center.X + localX * cos - localY * sin;
                    double y = center.Y + localX * sin + localY * cos;
                    if (IsPointInsidePolyline(boundaryPoints, x, y) && DistanceToPolyline(boundaryPoints, x, y) >= margin - 0.000001)
                        candidatePoints.Add(new Point3d(x, y, z));
                }
                }
                row++;
            }
            double uniformScale = CalculateUniformPlantScale(candidatePoints, plantSpread);
            int reduced = uniformScale < 0.999 ? candidatePoints.Count : 0;
            List<Point3d> accepted = new List<Point3d>();
            foreach (Point3d candidate in candidatePoints)
            {
                PlacePlantBlock(plantName, plantType, plantCategory, plantCode, plantHeight, plantSpread, plantTrunkDiameter, candidate, uniformScale, rotationDegrees);
                accepted.Add(candidate);
            }
            editor.WriteMessage("\nArea distribution complete: " + accepted.Count + " placed, " + reduced + " scaled uniformly. Pattern=" + (staggered ? "Staggered" : "Grid") + ", Margin=" + margin.ToString("0.##"));
        }

        private static List<double> BuildAxisSamples(double minimum, double maximum, double spacing)
        {
            List<double> values = new List<double>();
            if (spacing <= 0 || maximum < minimum) return values;
            double first = minimum + spacing * 0.5;
            double last = maximum - spacing * 0.5;
            for (double value = first; value <= last + 0.000001; value += spacing)
                values.Add(value);
            if (last < first - 0.000001)
                values.Add((minimum + maximum) * 0.5);
            else if (values.Count == 0 || Math.Abs(values[values.Count - 1] - last) > 0.000001)
                values.Add(last);
            return values;
        }

        private static bool ReadSpacing(Editor editor, out double horizontalSpacing,
            out double verticalSpacing)
        {
            horizontalSpacing = 2.0;
            verticalSpacing = 2.0;

            PromptDoubleOptions horizontalPrompt = new PromptDoubleOptions("\nHorizontal spacing <2.0>: ");
            horizontalPrompt.AllowNone = true;
            horizontalPrompt.DefaultValue = 2.0;
            horizontalPrompt.AllowZero = false;
            horizontalPrompt.AllowNegative = false;
            PromptDoubleResult horizontalResult = editor.GetDouble(horizontalPrompt);
            if (horizontalResult.Status != PromptStatus.OK && horizontalResult.Status != PromptStatus.None)
                return false;
            horizontalSpacing = horizontalResult.Status == PromptStatus.None ? 2.0 : horizontalResult.Value;

            PromptDoubleOptions verticalPrompt = new PromptDoubleOptions("\nVertical spacing <2.0>: ");
            verticalPrompt.AllowNone = true;
            verticalPrompt.DefaultValue = 2.0;
            verticalPrompt.AllowZero = false;
            verticalPrompt.AllowNegative = false;
            PromptDoubleResult verticalResult = editor.GetDouble(verticalPrompt);
            if (verticalResult.Status != PromptStatus.OK && verticalResult.Status != PromptStatus.None)
                return false;
            verticalSpacing = verticalResult.Status == PromptStatus.None ? 2.0 : verticalResult.Value;
            return true;
        }

        private static bool ReadOptionalDistance(Editor editor, string message, double defaultValue, out double value)
        {
            value = defaultValue;
            PromptDoubleOptions prompt = new PromptDoubleOptions(message)
            { AllowNone = true, DefaultValue = defaultValue, AllowZero = true, AllowNegative = false };
            PromptDoubleResult result = editor.GetDouble(prompt);
            if (result.Status != PromptStatus.OK && result.Status != PromptStatus.None) return false;
            value = result.Status == PromptStatus.None ? defaultValue : result.Value;
            return true;
        }

        private static double GetEntityAngle(Database database, ObjectId objectId)
        {
            using (Transaction transaction = database.TransactionManager.StartTransaction())
            {
                Entity entity = transaction.GetObject(objectId, OpenMode.ForRead) as Entity;
                Line line = entity as Line;
                if (line != null)
                {
                    transaction.Commit();
                    return line.Angle * 180.0 / Math.PI;
                }
                Polyline polyline = entity as Polyline;
                if (polyline != null && polyline.NumberOfVertices > 1)
                {
                    Point2d a = polyline.GetPoint2dAt(0), b = polyline.GetPoint2dAt(1);
                    transaction.Commit();
                    return Math.Atan2(b.Y - a.Y, b.X - a.X) * 180.0 / Math.PI;
                }
                transaction.Commit();
            }
            return 0.0;
        }

        private static Point2d[] TessellatePolyline(Polyline polyline, bool endpointClosed)
        {
            List<Point2d> samples = new List<Point2d>();
            int vertexCount = polyline.NumberOfVertices;
            int segmentCount = polyline.Closed ? vertexCount : vertexCount - 1;
            for (int segment = 0; segment < segmentCount; segment++)
            {
                double bulge = polyline.GetBulgeAt(segment);
                double sweep = Math.Abs(4.0 * Math.Atan(bulge));
                int steps = Math.Max(1, (int)Math.Ceiling(sweep / (Math.PI / 18.0)));
                for (int step = 0; step < steps; step++)
                {
                    double parameter = segment + (double)step / steps;
                    Point3d point = polyline.GetPointAtParameter(parameter);
                    samples.Add(new Point2d(point.X, point.Y));
                }
            }
            return samples.ToArray();
        }

        private static double CalculateUniformPlantScale(List<Point3d> points, double plantSpread)
        {
            if (points.Count < 2)
                return 1.0;
            double minimumCenterDistance = double.MaxValue;
            for (int i = 0; i < points.Count; i++)
            {
                for (int j = i + 1; j < points.Count; j++)
                {
                    double distance = points[i].DistanceTo(points[j]);
                    if (distance < minimumCenterDistance)
                        minimumCenterDistance = distance;
                }
            }
            if (minimumCenterDistance == double.MaxValue || minimumCenterDistance <= 0.000001)
                return 1.0;
            double requiredDiameter = Math.Max(0.01, plantSpread);
            // Keep a visible safety gap so neighboring canopies do not touch.
            return Math.Max(0.01, Math.Min(1.0, (minimumCenterDistance / requiredDiameter) * 0.82));
        }

        private static bool IsFarEnoughFromBoundary(Point2d[] points, double x, double y,
            double horizontalSpacing, double verticalSpacing)
        {
            Point2d sample = new Point2d(x, y);
            double requiredMinimum = double.MaxValue;
            for (int i = 0, j = points.Length - 1; i < points.Length; j = i++)
            {
                Point2d a = points[j];
                Point2d b = points[i];
                Vector2d edge = b - a;
                double length = edge.Length;
                if (length < 0.0000001)
                    continue;
                Vector2d tangent = edge / length;
                Vector2d normal = new Vector2d(-tangent.Y, tangent.X);
                double directionalHalfSpacing = 0.5 * Math.Sqrt(
                    normal.X * normal.X * horizontalSpacing * horizontalSpacing +
                    normal.Y * normal.Y * verticalSpacing * verticalSpacing);
                if (directionalHalfSpacing < requiredMinimum)
                    requiredMinimum = directionalHalfSpacing;

                double parameter = ((sample - a).DotProduct(edge)) / (length * length);
                parameter = Math.Max(0.0, Math.Min(1.0, parameter));
                Point2d closest = a + edge * parameter;
                if (sample.GetDistanceTo(closest) < directionalHalfSpacing - 0.000001)
                    return false;
            }
            return requiredMinimum != double.MaxValue;
        }

        private static double DistanceToPolyline(Point2d[] points, double x, double y)
        {
            Point2d sample = new Point2d(x, y);
            double minimum = double.MaxValue;
            for (int i = 0, j = points.Length - 1; i < points.Length; j = i++)
            {
                Point2d a = points[j], b = points[i];
                Vector2d edge = b - a;
                double lengthSquared = edge.DotProduct(edge);
                if (lengthSquared < 0.0000001) continue;
                double parameter = ((sample - a).DotProduct(edge)) / lengthSquared;
                parameter = Math.Max(0.0, Math.Min(1.0, parameter));
                Point2d closest = a + edge * parameter;
                minimum = Math.Min(minimum, sample.GetDistanceTo(closest));
            }
            return minimum;
        }

        private static bool IsPointInsidePolyline(Point2d[] points, double x, double y)
        {
            bool inside = false;
            int count = points.Length;
            for (int i = 0, j = count - 1; i < count; j = i++)
            {
                Point2d current = points[i];
                Point2d previous = points[j];
                bool crosses = (current.Y > y) != (previous.Y > y);
                if (!crosses)
                    continue;
                double intersectionX = (previous.X - current.X) * (y - current.Y) /
                    (previous.Y - current.Y) + current.X;
                if (x < intersectionX)
                    inside = !inside;
            }
            return inside;
        }

        [CommandMethod("OLFPLANTSCHEDULE")]
        public void PlantSchedule()
        {
            Database database = ActiveDocument().Database;
            Dictionary<string, Dictionary<string, PlantScheduleRecord>> groups =
                new Dictionary<string, Dictionary<string, PlantScheduleRecord>>(StringComparer.OrdinalIgnoreCase);
            using (Transaction transaction = database.TransactionManager.StartTransaction())
            {
                BlockTableRecord modelSpace = (BlockTableRecord)transaction.GetObject(
                    SymbolUtilityServices.GetBlockModelSpaceId(database), OpenMode.ForRead);
                foreach (ObjectId objectId in modelSpace)
                {
                    BlockReference reference = transaction.GetObject(objectId, OpenMode.ForRead) as BlockReference;
                    if (reference == null) continue;
                    ResultBuffer data = reference.GetXDataForApplication(AppName);
                    if (data == null) continue;
                    string name = GetPlantName(data);
                    string type = GetPlantType(data);
                    string category = GetPlantCategory(data);
                    string scientific = GetPlantScientific(data);
                    double height = GetPlantNumber(data, 4, 1.0);
                    double spread = GetPlantNumber(data, 5, 1.0);
                    double trunk = GetPlantNumber(data, 6, 0.0);
                    data.Dispose();
                    if (name.Length == 0) continue;
                    if (!groups.ContainsKey(category)) groups[category] = new Dictionary<string, PlantScheduleRecord>(StringComparer.OrdinalIgnoreCase);
                    if (!groups[category].ContainsKey(name))
                        groups[category][name] = new PlantScheduleRecord(name, scientific, height, spread, trunk, 0);
                    groups[category][name].Quantity++;
                }
                transaction.Commit();
            }
            if (groups.Count == 0)
            {
                ActiveEditor().WriteMessage("\nNo Open Landscape FX plants found.");
                return;
            }
            PromptPointResult point = ActiveEditor().GetPoint("\nSelect first schedule insertion point: ");
            if (point.Status != PromptStatus.OK) return;
            using (Transaction transaction = database.TransactionManager.StartTransaction())
            {
                OLFProjectSettings scheduleSettings = ProjectSettingsStore.Load();
                EnsureLayer(database, transaction, scheduleSettings.ScheduleLayer);
                BlockTableRecord modelSpace = (BlockTableRecord)transaction.GetObject(
                    SymbolUtilityServices.GetBlockModelSpaceId(database), OpenMode.ForWrite);
                double y = point.Value.Y;
                foreach (KeyValuePair<string, Dictionary<string, PlantScheduleRecord>> group in groups)
                {
                    Table table = new Table();
                    table.TableStyle = database.Tablestyle;
                    table.Layer = ProjectSettingsStore.Load().ScheduleLayer;
                    table.SetSize(group.Value.Count + 2, 9);
                    table.Position = new Point3d(point.Value.X, y, point.Value.Z);
                    table.SetRowHeight(0.8);
                    for (int col = 0; col < 9; col++) table.SetColumnWidth(col, col == 0 ? 2.2 : 2.4);
                    table.SetTextString(0, 0, group.Key);
                    table.SetTextString(1, 0, "Symbol");
                    table.SetTextString(1, 1, "Code");
                    table.SetTextString(1, 2, "Scientific name");
                    table.SetTextString(1, 3, "Common name");
                    table.SetTextString(1, 4, "Height");
                    table.SetTextString(1, 5, "Spread");
                    table.SetTextString(1, 6, "Trunk");
                    table.SetTextString(1, 7, "Quantity");
                    table.SetTextString(1, 8, "Unit");
                    int row = 2;
                    foreach (PlantScheduleRecord item in group.Value.Values)
                    {
                        ObjectId symbolBlock = FindPlantBlock(database, transaction, item.CommonName);
                        if (!symbolBlock.IsNull)
                        {
                            table.SetBlockTableRecordId(row, 0, symbolBlock, false);
                            table.SetBlockScale(row, 0, 0.28);
                        }
                        else
                            table.SetTextString(row, 0, MakePlantSymbol(item.CommonName));
                        table.SetTextString(row, 1, PlantCatalog.Items.Find(x => x.CommonName == item.CommonName)?.Code ?? "UNK");
                        table.SetTextString(row, 2, item.ScientificName);
                        table.SetTextString(row, 3, item.CommonName);
                        table.SetTextString(row, 4, item.Height.ToString("0.##"));
                        table.SetTextString(row, 5, item.Spread.ToString("0.##"));
                        table.SetTextString(row, 6, item.Trunk.ToString("0.##"));
                        table.SetTextString(row, 7, item.Quantity.ToString());
                        table.SetTextString(row, 8, "EA");
                        row++;
                    }
                    for (int alignmentRow = 0; alignmentRow < group.Value.Count + 2; alignmentRow++)
                        for (int alignmentColumn = 0; alignmentColumn < 9; alignmentColumn++)
                            table.SetAlignment(alignmentRow, alignmentColumn, CellAlignment.MiddleCenter);
                    modelSpace.AppendEntity(table);
                    transaction.AddNewlyCreatedDBObject(table, true);
                    y -= (group.Value.Count + 2) * 0.8 + 1.2;
                }
                transaction.Commit();
            }
            ActiveEditor().WriteMessage("\nCreated " + groups.Count + " category plant schedules.");
        }

        [CommandMethod("OLFVERIFYPLANTS")]
        public void VerifyPlants()
        {
            Database database = ActiveDocument().Database;
            int total = 0;
            int valid = 0;
            int missingCode = 0;
            int invalidDimensions = 0;
            using (Transaction transaction = database.TransactionManager.StartTransaction())
            {
                BlockTableRecord modelSpace = (BlockTableRecord)transaction.GetObject(
                    SymbolUtilityServices.GetBlockModelSpaceId(database), OpenMode.ForRead);
                foreach (ObjectId objectId in modelSpace)
                {
                    BlockReference reference = transaction.GetObject(objectId, OpenMode.ForRead) as BlockReference;
                    if (reference == null) continue;
                    ResultBuffer data = reference.GetXDataForApplication(AppName);
                    if (data == null) continue;
                    total++;
                    string code = GetPlantCode(data);
                    double height = GetPlantNumber(data, 4, -1.0);
                    double spread = GetPlantNumber(data, 5, -1.0);
                    data.Dispose();
                    bool itemValid = true;
                    if (code == "UNK") { missingCode++; itemValid = false; }
                    if (height <= 0 || spread <= 0) { invalidDimensions++; itemValid = false; }
                    if (itemValid) valid++;
                }
                transaction.Commit();
            }
            ActiveEditor().WriteMessage("\nOLF plant verification");
            ActiveEditor().WriteMessage("\nTotal: " + total + " | Valid: " + valid +
                " | Missing code: " + missingCode + " | Invalid dimensions: " + invalidDimensions);
        }

        private class PlantScheduleRecord
        {
            public string CommonName; public string ScientificName; public double Height; public double Spread; public double Trunk; public int Quantity;
            public PlantScheduleRecord(string common, string scientific, double height, double spread, double trunk, int quantity)
            { CommonName = common; ScientificName = scientific; Height = height; Spread = spread; Trunk = trunk; Quantity = quantity; }
        }

        private static ObjectId FindPlantBlock(Database database, Transaction transaction, string commonName)
        {
            BlockTable table = (BlockTable)transaction.GetObject(database.BlockTableId, OpenMode.ForRead);
            string prefix = "OLF2_PLANT_";
            foreach (ObjectId id in table)
            {
                BlockTableRecord record = transaction.GetObject(id, OpenMode.ForRead) as BlockTableRecord;
                if (record != null && record.Name.StartsWith(prefix, StringComparison.OrdinalIgnoreCase) &&
                    record.Name.IndexOf(commonName.Trim().ToUpperInvariant().Replace(" ", "_"), StringComparison.OrdinalIgnoreCase) >= 0)
                    return id;
            }
            return ObjectId.Null;
        }

        private static string MakePlantSymbol(string name)
        {
            string result = name.Trim().ToUpperInvariant().Replace(" ", "_");
            return result.Length > 12 ? result.Substring(0, 12) : result;
        }

        [CommandMethod("OLFLABELPLANTS")]
        public void LabelPlants()
        {
            Editor editor = ActiveEditor();
            PromptKeywordOptions scopePrompt = new PromptKeywordOptions("\nLabel [All/Select] <All>: ");
            scopePrompt.AllowNone = true;
            scopePrompt.Keywords.Add("All");
            scopePrompt.Keywords.Add("Select");
            PromptResult scopeResult = editor.GetKeywords(scopePrompt);
            if (scopeResult.Status != PromptStatus.OK && scopeResult.Status != PromptStatus.None)
                return;
            bool selectedOnly = scopeResult.Status == PromptStatus.OK &&
                scopeResult.StringResult.Equals("Select", StringComparison.OrdinalIgnoreCase);
            ObjectId[] selectedIds = null;
            if (selectedOnly)
            {
                PromptSelectionResult selection = editor.GetSelection(
                    new PromptSelectionOptions { MessageForAdding = "\nSelect plants to label: " });
                if (selection.Status != PromptStatus.OK)
                    return;
                selectedIds = selection.Value.GetObjectIds();
            }
            Database database = ActiveDocument().Database;
            OLFProjectSettings settings = ProjectSettingsStore.Load();
            int labelsCreated = 0;
            using (Transaction transaction = database.TransactionManager.StartTransaction())
            {
                BlockTableRecord modelSpace = (BlockTableRecord)transaction.GetObject(
                    SymbolUtilityServices.GetBlockModelSpaceId(database), OpenMode.ForWrite);
                List<ObjectId> oldLabels = new List<ObjectId>();
                List<ObjectId> plants = new List<ObjectId>();
                HashSet<string> targetPlantHandles = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                foreach (ObjectId objectId in modelSpace)
                {
                    Entity entity = transaction.GetObject(objectId, OpenMode.ForRead) as Entity;
                    if (entity == null) continue;
                    BlockReference reference = entity as BlockReference;
                    if (selectedOnly && Array.IndexOf(selectedIds, objectId) < 0)
                        reference = null;
                    if (reference != null && reference.GetXDataForApplication(AppName) != null)
                    {
                        plants.Add(objectId);
                        targetPlantHandles.Add(objectId.Handle.ToString());
                    }
                    if (entity.Layer == settings.LabelLayer)
                    {
                        MLeader existingLeader = entity as MLeader;
                        if (existingLeader != null)
                        {
                            if (LabelTargetsPlant(existingLeader, targetPlantHandles)) oldLabels.Add(objectId); 
                        }
                    }
                }
                foreach (ObjectId objectId in oldLabels)
                {
                    Entity entity = transaction.GetObject(objectId, OpenMode.ForWrite) as Entity;
                    if (entity != null) entity.Erase();
                }
                EnsureLayer(database, transaction, settings.LabelLayer);
                EnsureRegApp(database, transaction, LabelAppName);
                foreach (ObjectId objectId in plants)
                {
                    BlockReference reference = transaction.GetObject(objectId, OpenMode.ForRead) as BlockReference;
                    ResultBuffer data = reference.GetXDataForApplication(AppName);
                    string code = GetPlantCode(data);
                    data.Dispose();
                    if (code == "UNK") continue;
                    Extents3d bounds;
                    try { bounds = reference.GeometricExtents; }
                    catch { bounds = new Extents3d(reference.Position, reference.Position); }
                    double size = Math.Max(bounds.MaxPoint.X - bounds.MinPoint.X, bounds.MaxPoint.Y - bounds.MinPoint.Y);
                    double textHeight = Math.Max(0.01, Math.Min(settings.TextHeight, size * 0.18));
                    Point3d arrowPoint = reference.Position;
                    Point3d textPoint = arrowPoint + new Vector3d(Math.Max(size * settings.LeaderOffsetX, settings.LeaderOffsetX),
                        Math.Max(size * settings.LeaderOffsetY, settings.LeaderOffsetY), 0);
                    MLeader leader = new MLeader();
                    leader.Layer = settings.LabelLayer;
                    leader.Scale = 1.0;
                    leader.EnableAnnotationScale = false;
                    leader.ArrowSize = Math.Max(0.01, Math.Min(settings.ArrowSize, size * 0.08));
                    leader.TextHeight = textHeight;
                    leader.ExtendLeaderToText = false;
                    leader.ContentType = ContentType.MTextContent;
                    int leaderIndex = leader.AddLeader();
                    int lineIndex = leader.AddLeaderLine(leaderIndex);
                    leader.SetLeaderLineType(lineIndex, LeaderType.SplineLeader);
                    leader.AddFirstVertex(lineIndex, arrowPoint);
                    leader.AddLastVertex(lineIndex, textPoint);
                    leader.EnableLanding = true;
                    leader.LandingGap = settings.LandingGap;
                    leader.EnableDogleg = true;
                    leader.DoglegLength = settings.DoglegLength;
                    MText content = new MText();
                    content.Contents = code;
                    content.TextHeight = textHeight;
                    content.Attachment = AttachmentPoint.MiddleLeft;
                    content.Location = textPoint;
                    leader.MText = content;
                    leader.XData = new ResultBuffer(
                        new TypedValue((int)DxfCode.ExtendedDataRegAppName, LabelAppName),
                        new TypedValue((int)DxfCode.ExtendedDataAsciiString, reference.ObjectId.Handle.ToString()));
                    modelSpace.AppendEntity(leader);
                    transaction.AddNewlyCreatedDBObject(leader, true);
                    labelsCreated++;
                }
                transaction.Commit();
            }
            ActiveEditor().WriteMessage("\nCreated " + labelsCreated + " simple plant MLeaders.");
        }

        private static void EraseLabelsForPlants(Transaction transaction, BlockTableRecord modelSpace,
            HashSet<string> plantHandles)
        {
            List<ObjectId> labelsToErase = new List<ObjectId>();
            foreach (ObjectId objectId in modelSpace)
            {
                MLeader leader = transaction.GetObject(objectId, OpenMode.ForRead) as MLeader;
                if (leader != null && LabelTargetsPlant(leader, plantHandles))
                    labelsToErase.Add(objectId);
            }
            foreach (ObjectId objectId in labelsToErase)
            {
                MLeader leader = transaction.GetObject(objectId, OpenMode.ForWrite) as MLeader;
                if (leader != null) leader.Erase();
            }
        }

        private static bool LabelTargetsPlant(MLeader leader, HashSet<string> targetPlantHandles)
        {
            ResultBuffer data = leader.GetXDataForApplication(LabelAppName);
            if (data == null)
                return false;
            foreach (TypedValue value in data)
            {
                if (value.TypeCode == (int)DxfCode.ExtendedDataAsciiString &&
                    targetPlantHandles.Contains(Convert.ToString(value.Value) ?? string.Empty))
                {
                    data.Dispose();
                    return true;
                }
            }
            data.Dispose();
            return false;
        }

        private static string GetLabelTargetHandle(MLeader leader)
        {
            ResultBuffer data = leader.GetXDataForApplication(LabelAppName);
            if (data == null) return string.Empty;
            foreach (TypedValue value in data)
                if (value.TypeCode == (int)DxfCode.ExtendedDataAsciiString)
                {
                    string result = Convert.ToString(value.Value) ?? string.Empty;
                    data.Dispose();
                    return result;
                }
            data.Dispose();
            return string.Empty;
        }

        private static void SetPlantXData(BlockReference reference, Database database, Transaction transaction,
            string plantName, string plantType, string plantCategory, string plantCode,
            double plantHeight, double plantSpread, double plantTrunkDiameter)
        {
            EnsureRegApp(database, transaction, AppName);
            reference.XData = new ResultBuffer(
                new TypedValue((int)DxfCode.ExtendedDataRegAppName, AppName),
                new TypedValue((int)DxfCode.ExtendedDataAsciiString, plantName),
                new TypedValue((int)DxfCode.ExtendedDataAsciiString, plantType),
                new TypedValue((int)DxfCode.ExtendedDataAsciiString, plantCategory),
                new TypedValue((int)DxfCode.ExtendedDataAsciiString, plantCode),
                new TypedValue((int)DxfCode.ExtendedDataAsciiString, plantHeight.ToString(System.Globalization.CultureInfo.InvariantCulture)),
                new TypedValue((int)DxfCode.ExtendedDataAsciiString, plantSpread.ToString(System.Globalization.CultureInfo.InvariantCulture)),
                new TypedValue((int)DxfCode.ExtendedDataAsciiString, plantTrunkDiameter.ToString(System.Globalization.CultureInfo.InvariantCulture)));
        }

        private static void PlacePlantBlock(string plantName, string plantType, string plantCategory,
            string plantCode, double plantHeight, double plantSpread, double plantTrunkDiameter, Point3d point,
            double uniformScale = 1.0, double rotationDegrees = 0.0)
        {
            Database database = ActiveDocument().Database;
            OLFProjectSettings settings = ProjectSettingsStore.Load();
            using (Transaction transaction = database.TransactionManager.StartTransaction())
            {
                EnsureLayer(database, transaction, settings.PlantLayer);
                EnsureRegApp(database, transaction, AppName);
                string blockName = GetBlockName(plantName, plantType);
                BlockTable blockTable = (BlockTable)transaction.GetObject(database.BlockTableId, OpenMode.ForRead);
                ObjectId blockId = blockTable.Has(blockName)
                    ? blockTable[blockName]
                    : CreatePlantBlock(database, transaction, blockName, plantType, plantCategory,
                        plantHeight, plantSpread, plantTrunkDiameter);
                BlockTableRecord modelSpace = (BlockTableRecord)transaction.GetObject(
                    SymbolUtilityServices.GetBlockModelSpaceId(database), OpenMode.ForWrite);
                BlockReference reference = new BlockReference(point, blockId);
                reference.ScaleFactors = new Scale3d(uniformScale);
                reference.Rotation = rotationDegrees * Math.PI / 180.0;
                reference.Layer = settings.PlantLayer;
                modelSpace.AppendEntity(reference);
                transaction.AddNewlyCreatedDBObject(reference, true);
                reference.XData = new ResultBuffer(
                    new TypedValue((int)DxfCode.ExtendedDataRegAppName, AppName),
                    new TypedValue((int)DxfCode.ExtendedDataAsciiString, plantName),
                    new TypedValue((int)DxfCode.ExtendedDataAsciiString, plantType),
                    new TypedValue((int)DxfCode.ExtendedDataAsciiString, plantCategory),
                    new TypedValue((int)DxfCode.ExtendedDataAsciiString, plantCode),
                    new TypedValue((int)DxfCode.ExtendedDataAsciiString, plantHeight.ToString(System.Globalization.CultureInfo.InvariantCulture)),
                    new TypedValue((int)DxfCode.ExtendedDataAsciiString, plantSpread.ToString(System.Globalization.CultureInfo.InvariantCulture)),
                    new TypedValue((int)DxfCode.ExtendedDataAsciiString, plantTrunkDiameter.ToString(System.Globalization.CultureInfo.InvariantCulture)));
                transaction.Commit();
            }
        }

        private static ObjectId CreatePlantBlock(Database database, Transaction transaction, string blockName,
            string plantType, string plantCategory, double plantHeight, double plantSpread, double plantTrunkDiameter)
        {
            BlockTable blockTable = (BlockTable)transaction.GetObject(database.BlockTableId, OpenMode.ForWrite);
            BlockTableRecord definition = new BlockTableRecord { Name = blockName };
            blockTable.Add(definition);
            transaction.AddNewlyCreatedDBObject(definition, true);

            short color = GetCategoryColor(plantCategory);
            double canopyRadius = Math.Max(0.25, plantSpread * 0.5);
            if (plantCategory == "Palm")
            {
                for (int i = 0; i < 8; i++)
                {
                    double angle = i * Math.PI / 4.0;
                    Line leaf = new Line(Point3d.Origin, new Point3d(Math.Cos(angle) * canopyRadius, Math.Sin(angle) * canopyRadius, 0));
                    leaf.ColorIndex = color; Append(definition, transaction, leaf);
                }
            }
            else if (plantCategory == "Large Tree" || plantCategory == "Small Tree")
            {
                Circle canopy = new Circle(Point3d.Origin, Vector3d.ZAxis, canopyRadius);
                canopy.ColorIndex = color; Append(definition, transaction, canopy);
                Circle canopy2 = new Circle(new Point3d(canopyRadius * 0.55, 0, 0), Vector3d.ZAxis, canopyRadius * 0.45);
                canopy2.ColorIndex = color; Append(definition, transaction, canopy2);
            }
            else if (plantCategory == "Groundcover")
            {
                Circle symbol = new Circle(Point3d.Origin, Vector3d.ZAxis, canopyRadius);
                symbol.ColorIndex = color; Append(definition, transaction, symbol);
                Line crossA = new Line(new Point3d(-canopyRadius, 0, 0), new Point3d(canopyRadius, 0, 0));
                Line crossB = new Line(new Point3d(0, -canopyRadius, 0), new Point3d(0, canopyRadius, 0));
                crossA.ColorIndex = color; crossB.ColorIndex = color;
                Append(definition, transaction, crossA); Append(definition, transaction, crossB);
            }
            else if (plantCategory == "Cactus")
            {
                Circle cactus = new Circle(Point3d.Origin, Vector3d.ZAxis, canopyRadius);
                cactus.ColorIndex = color; Append(definition, transaction, cactus);
                Line arm = new Line(new Point3d(-canopyRadius, 0, 0), new Point3d(canopyRadius, 0, 0));
                arm.ColorIndex = color; Append(definition, transaction, arm);
            }
            else
            {
                Circle shrub = new Circle(Point3d.Origin, Vector3d.ZAxis, canopyRadius);
                shrub.ColorIndex = color; Append(definition, transaction, shrub);
            }
            return definition.ObjectId;
        }

        private static short GetCategoryColor(string category)
        {
            if (category == "Palm") return 1;          // red
            if (category == "Large Tree") return 4;    // cyan
            if (category == "Small Tree") return 32;   // brown-ish
            if (category == "Large Shrub" || category == "Small Shrub") return 2; // yellow
            if (category == "Groundcover") return 3;   // green
            if (category == "Cactus") return 5;        // blue
            return 7;
        }

        private static void Append(BlockTableRecord definition, Transaction transaction, Entity entity)
        {
            definition.AppendEntity(entity);
            transaction.AddNewlyCreatedDBObject(entity, true);
        }

        private static void EnsureRegApp(Database database, Transaction transaction, string name)
        {
            RegAppTable table = (RegAppTable)transaction.GetObject(database.RegAppTableId, OpenMode.ForRead);
            if (table.Has(name))
                return;
            table.UpgradeOpen();
            RegAppTableRecord record = new RegAppTableRecord { Name = name };
            table.Add(record);
            transaction.AddNewlyCreatedDBObject(record, true);
        }

        private static string GetPlantName(ResultBuffer data)
        {
            int textIndex = 0;
            foreach (TypedValue value in data)
            {
                if (value.TypeCode == (int)DxfCode.ExtendedDataAsciiString)
                {
                    if (textIndex == 0)
                        return Convert.ToString(value.Value) ?? string.Empty;
                    textIndex++;
                }
            }
            return string.Empty;
        }

        private static string GetPlantType(ResultBuffer data)
        {
            int textIndex = 0;
            foreach (TypedValue value in data)
            {
                if (value.TypeCode == (int)DxfCode.ExtendedDataAsciiString)
                {
                    if (textIndex == 1)
                        return Convert.ToString(value.Value) ?? "Shrub";
                    textIndex++;
                }
            }
            return "Shrub";
        }

        private static string GetPlantScientific(ResultBuffer data)
        {
            string name = GetPlantName(data);
            foreach (PlantCatalogItem item in PlantCatalog.Items)
                if (String.Equals(item.CommonName, name, StringComparison.OrdinalIgnoreCase)) return item.ScientificName;
            return "-";
        }

        private static string GetPlantCode(ResultBuffer data)
        {
            int index = 0;
            foreach (TypedValue value in data)
                if (value.TypeCode == (int)DxfCode.ExtendedDataAsciiString && index++ == 3)
                    return Convert.ToString(value.Value) ?? "UNK";
            return "UNK";
        }

        private static string GetPlantCategory(ResultBuffer data)
        {
            int index = 0;
            foreach (TypedValue value in data)
                if (value.TypeCode == (int)DxfCode.ExtendedDataAsciiString && index++ == 2)
                    return Convert.ToString(value.Value) ?? "Small Shrub";
            return "Small Shrub";
        }

        private static double GetPlantNumber(ResultBuffer data, int textIndex, double fallback)
        {
            int index = 0;
            foreach (TypedValue value in data)
                if (value.TypeCode == (int)DxfCode.ExtendedDataAsciiString && index++ == textIndex)
                {
                    double number;
                    if (double.TryParse(Convert.ToString(value.Value), System.Globalization.NumberStyles.Float,
                        System.Globalization.CultureInfo.InvariantCulture, out number)) return number;
                }
            return fallback;
        }

        private static void EnsureLayer(Database database, Transaction transaction, string name)
        {
            LayerTable table = (LayerTable)transaction.GetObject(database.LayerTableId, OpenMode.ForRead);
            if (table.Has(name))
                return;
            table.UpgradeOpen();
            LayerTableRecord layer = new LayerTableRecord { Name = name };
            table.Add(layer);
            transaction.AddNewlyCreatedDBObject(layer, true);
        }

        private static string GetBlockName(string plantName, string plantType)
        {
            foreach (PlantCatalogItem item in PlantCatalog.Items)
                if (String.Equals(item.CommonName, plantName, StringComparison.OrdinalIgnoreCase) &&
                    !String.IsNullOrWhiteSpace(item.SymbolName))
                    return item.SymbolName.Trim();
            string safeName = plantName.Trim().ToUpperInvariant().Replace(" ", "_");
            string safeType = plantType.Trim().ToUpperInvariant();
            return "OLF2_PLANT_" + safeType + "_" + safeName;
        }

        private static Document ActiveDocument() { return Application.DocumentManager.MdiActiveDocument; }
        private static Editor ActiveEditor() { return ActiveDocument().Editor; }
    }
}
