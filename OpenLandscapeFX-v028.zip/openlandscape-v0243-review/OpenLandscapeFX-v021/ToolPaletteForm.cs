using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace OpenLandscapeFx
{
    public class ToolPaletteForm : Form
    {
        public string SelectedCommand { get; private set; }
        private readonly FlowLayoutPanel categoryPanel;
        private readonly FlowLayoutPanel commandPanel;
        private Label commandTitle;
        private readonly Dictionary<string, Button> categoryButtons = new Dictionary<string, Button>();
        private readonly Dictionary<string, Tool[]> commandGroups = new Dictionary<string, Tool[]>();

        public ToolPaletteForm()
        {
            Text = "Open Landscape FX";
            Width = 840; Height = 570;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false; MinimizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.FromArgb(24, 32, 45);

            Label header = new Label { Text = "Open Landscape FX", Left = 24, Top = 18, Width = 760, Height = 36,
                ForeColor = Color.White, Font = new Font(DefaultFont.FontFamily, 16, FontStyle.Bold) };
            Controls.Add(header);
            Controls.Add(new Label { Text = "Choose a category, then choose a command", Left = 26, Top = 51, Width = 500,
                ForeColor = Color.FromArgb(180, 195, 212) });

            categoryPanel = new FlowLayoutPanel { Left = 20, Top = 88, Width = 285, Height = 400,
                FlowDirection = FlowDirection.TopDown, WrapContents = false, Padding = new Padding(0, 4, 0, 0),
                BackColor = Color.FromArgb(30, 42, 58) };
            commandPanel = new FlowLayoutPanel { Left = 318, Top = 88, Width = 490, Height = 400,
                FlowDirection = FlowDirection.TopDown, WrapContents = false, Padding = new Padding(28, 18, 18, 18),
                BackColor = Color.FromArgb(38, 52, 70) };
            Controls.Add(categoryPanel); Controls.Add(commandPanel);

            commandGroups["Add Plants"] = new[] {
                new Tool("Plant Manager", "OLFPLANTMANAGER"), new Tool("Place Area", "OLFPLACEAREA"),
                new Tool("Plant Path", "OLFPLANTPATH"), new Tool("Plant Row", "OLFPLANTROW"),
                new Tool("Area Preview", "OLFAREAPREVIEW") };
            commandGroups["Modify"] = new[] {
                new Tool("Replace Plant", "OLFREPLACEPLANT"), new Tool("Delete Plant", "OLFDELETEPLANT") };
            commandGroups["Labels & Schedules"] = new[] {
                new Tool("Label Plants", "OLFLABELPLANTS"), new Tool("Plant Schedule", "OLFPLANTSCHEDULE"),
                new Tool("Update Drawing", "OLFUPDATE") };
            commandGroups["Project & Data"] = new[] {
                new Tool("Plant Data Manager", "OLFPLANTDATA"), new Tool("Project Settings", "OLFSETTINGS"),
                new Tool("Setup Layers", "OLFSETUPLAYERS"), new Tool("New Project", "OLFNEWPROJECT") };
            commandGroups["Reports & Checks"] = new[] {
                new Tool("Verify Plants", "OLFVERIFYPLANTS"), new Tool("Plant Report", "OLFPLANTREPORT"),
                new Tool("Plant Legend", "OLFPLANTLEGEND"), new Tool("Quick Takeoff CSV", "OLFQUICKTAKEOFF") };

            foreach (string category in commandGroups.Keys) AddCategoryButton(category);
            ShowCommands("Add Plants");

            Button close = new Button { Text = "Close", Left = 690, Top = 505, Width = 105, Height = 34,
                BackColor = Color.FromArgb(58, 74, 94), ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
            close.Click += delegate { DialogResult = DialogResult.Cancel; Close(); };
            Controls.Add(close);
        }

        private void AddCategoryButton(string category)
        {
            Button button = new Button { Text = category, Width = 265, Height = 54, Margin = new Padding(10, 6, 10, 2),
                TextAlign = ContentAlignment.MiddleLeft, Padding = new Padding(18, 0, 0, 0),
                FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(42, 58, 77), ForeColor = Color.White,
                Font = new Font(DefaultFont.FontFamily, 10, FontStyle.Bold) };
            button.FlatAppearance.BorderColor = Color.FromArgb(68, 91, 117);
            button.Click += delegate { ShowCommands(category); };
            categoryButtons[category] = button;
            categoryPanel.Controls.Add(button);
        }

        private void ShowCommands(string category)
        {
            foreach (KeyValuePair<string, Button> pair in categoryButtons)
            {
                pair.Value.BackColor = pair.Key == category ? Color.FromArgb(25, 125, 225) : Color.FromArgb(42, 58, 77);
                pair.Value.FlatAppearance.BorderColor = pair.Key == category ? Color.FromArgb(90, 180, 255) : Color.FromArgb(68, 91, 117);
            }
            commandPanel.Controls.Clear();
            commandTitle = new Label { Text = category, Width = 420, Height = 38, ForeColor = Color.White,
                Font = new Font(DefaultFont.FontFamily, 13, FontStyle.Bold), Margin = new Padding(0, 0, 0, 12) };
            commandPanel.Controls.Add(commandTitle);
            foreach (Tool tool in commandGroups[category])
            {
                Button button = new Button { Text = tool.Caption + "  ›", Width = 420, Height = 48, Margin = new Padding(0, 5, 0, 5),
                    TextAlign = ContentAlignment.MiddleLeft, Padding = new Padding(18, 0, 0, 0),
                    FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(48, 66, 88), ForeColor = Color.White,
                    Font = new Font(DefaultFont.FontFamily, 10, FontStyle.Regular) };
                button.FlatAppearance.BorderColor = Color.FromArgb(82, 111, 143);
                button.Click += delegate { SelectedCommand = tool.Command; DialogResult = DialogResult.OK; Close(); };
                commandPanel.Controls.Add(button);
            }
        }

        private sealed class Tool
        {
            public readonly string Caption;
            public readonly string Command;
            public Tool(string caption, string command) { Caption = caption; Command = command; }
        }
    }
}
