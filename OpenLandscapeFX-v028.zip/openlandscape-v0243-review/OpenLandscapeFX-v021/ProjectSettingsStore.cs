using System;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;

namespace OpenLandscapeFx
{
    [DataContract]
    public class OLFProjectSettings
    {
        [DataMember] public double TextHeight = 0.12;
        [DataMember] public double ArrowSize = 0.10;
        [DataMember] public double LeaderOffsetX = 0.24;
        [DataMember] public double LeaderOffsetY = 0.18;
        [DataMember] public double LandingGap = 0.01;
        [DataMember] public double DoglegLength = 0.01;
        [DataMember] public string PlantLayer = "OLF_PLANTS";
        [DataMember] public string LabelLayer = "OLF_LABELS";
        [DataMember] public string ScheduleLayer = "OLF_SCHEDULES";
        [DataMember] public string BoundaryLayer = "OLF_BOUNDARIES";

        public void Normalize()
        {
            if (TextHeight <= 0) TextHeight = 0.12;
            if (ArrowSize <= 0) ArrowSize = 0.10;
            if (LeaderOffsetX <= 0) LeaderOffsetX = 0.24;
            if (LeaderOffsetY <= 0) LeaderOffsetY = 0.18;
            if (LandingGap < 0) LandingGap = 0.01;
            if (DoglegLength < 0) DoglegLength = 0.01;
            if (String.IsNullOrWhiteSpace(PlantLayer)) PlantLayer = "OLF_PLANTS";
            if (String.IsNullOrWhiteSpace(LabelLayer)) LabelLayer = "OLF_LABELS";
            if (String.IsNullOrWhiteSpace(ScheduleLayer)) ScheduleLayer = "OLF_SCHEDULES";
            if (String.IsNullOrWhiteSpace(BoundaryLayer)) BoundaryLayer = "OLF_BOUNDARIES";
        }
    }

    public static class ProjectSettingsStore
    {
        public static string FilePath
        {
            get
            {
                string folder = Path.GetDirectoryName(typeof(ProjectSettingsStore).Assembly.Location);
                return Path.Combine(folder ?? Environment.CurrentDirectory, "olf-settings.json");
            }
        }

        public static OLFProjectSettings Load()
        {
            OLFProjectSettings settings = new OLFProjectSettings();
            if (!File.Exists(FilePath)) { settings.Normalize(); return settings; }
            try
            {
                DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(OLFProjectSettings));
                using (FileStream stream = File.OpenRead(FilePath)) settings = serializer.ReadObject(stream) as OLFProjectSettings;
            }
            catch { settings = new OLFProjectSettings(); }
            if (settings == null) settings = new OLFProjectSettings();
            settings.Normalize();
            return settings;
        }

        public static void Save(OLFProjectSettings settings)
        {
            settings.Normalize();
            DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(OLFProjectSettings));
            using (FileStream stream = File.Create(FilePath)) serializer.WriteObject(stream, settings);
        }
    }
}
