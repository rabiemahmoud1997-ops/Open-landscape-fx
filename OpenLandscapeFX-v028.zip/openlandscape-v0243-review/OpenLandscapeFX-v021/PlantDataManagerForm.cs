using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace OpenLandscapeFx
{
    public class PlantDataManagerForm : Form
    {
        private readonly ListBox list;
        private readonly TextBox common;
        private readonly TextBox scientific;
        private readonly ComboBox category;
        private readonly ComboBox type;
        private readonly TextBox height;
        private readonly TextBox spread;
        private readonly TextBox trunk;
        private readonly TextBox search;
        private readonly ComboBox categoryFilter;

        public PlantDataManagerForm()
        {
            Text = "Open Landscape FX - Plant Data Manager";
            Width = 900; Height = 560; StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false;
            search = new TextBox { Left = 15, Top = 15, Width = 300 };
            categoryFilter = new ComboBox { Left = 15, Top = 48, Width = 300, DropDownStyle = ComboBoxStyle.DropDownList };
            categoryFilter.Items.Add("All categories"); categoryFilter.Items.AddRange(PlantCatalog.Categories); categoryFilter.SelectedIndex = 0;
            search.TextChanged += delegate { ReloadList(); }; categoryFilter.SelectedIndexChanged += delegate { ReloadList(); };
            Controls.Add(search); Controls.Add(categoryFilter);
            list = new ListBox { Left = 15, Top = 82, Width = 300, Height = 350 };
            list.SelectedIndexChanged += delegate { LoadSelected(); };
            Controls.Add(list);
            common = AddField("Common name", 345, 20);
            scientific = AddField("Scientific name", 345, 58);
            category = AddChoiceField("Category", PlantCatalog.Categories, 345, 96);
            type = AddChoiceField("Type", new[] { "Tree", "Shrub", "Groundcover", "Grass" }, 345, 134);
            height = AddField("Height", 345, 172);
            spread = AddField("Spread", 345, 210);
            trunk = AddField("Trunk", 345, 248);
            Button add = ButtonFor("Add New", 345, 300);
            Button update = ButtonFor("Update Selected", 475, 300);
            Button remove = ButtonFor("Delete", 605, 300);
            Button save = ButtonFor("Save JSON", 345, 350);
            Button close = ButtonFor("Close", 475, 350);
            Button duplicate = ButtonFor("Duplicate", 605, 350);
            Button import = ButtonFor("Import CSV", 345, 400);
            Button export = ButtonFor("Export CSV", 475, 400);
            Button reset = ButtonFor("Reset to Default", 605, 400);
            add.Click += delegate { AddNew(); };
            update.Click += delegate { UpdateSelected(); };
            remove.Click += delegate { DeleteSelected(); };
            save.Click += delegate { PlantCatalogStore.Save(); MessageBox.Show("Saved to:\n" + PlantCatalogStore.FilePath); };
            close.Click += delegate { DialogResult = DialogResult.Cancel; Close(); };
            duplicate.Click += delegate { DuplicateSelected(); };
            import.Click += delegate { ImportCsv(); };
            export.Click += delegate { ExportCsv(); };
            reset.Click += delegate { ResetToDefault(); };
            ReloadList();
        }

        private TextBox AddField(string caption, int left, int top)
        {
            Controls.Add(new Label { Text = caption + ":", Left = left, Top = top + 3, Width = 110 });
            TextBox box = new TextBox { Left = left + 115, Top = top, Width = 240 };
            Controls.Add(box); return box;
        }

        private ComboBox AddChoiceField(string caption, string[] values, int left, int top)
        {
            Controls.Add(new Label { Text = caption + ":", Left = left, Top = top + 3, Width = 110 });
            ComboBox box = new ComboBox { Left = left + 115, Top = top, Width = 240,
                DropDownStyle = ComboBoxStyle.DropDownList };
            box.Items.AddRange(values); Controls.Add(box); return box;
        }

        private Button ButtonFor(string text, int left, int top)
        {
            Button button = new Button { Text = text, Left = left, Top = top, Width = 115, Height = 30 };
            Controls.Add(button); return button;
        }

        private void ReloadList()
        {
            list.Items.Clear();
            string query = search == null ? string.Empty : search.Text.Trim();
            string filter = categoryFilter == null ? "All categories" : Convert.ToString(categoryFilter.SelectedItem);
            foreach (PlantCatalogItem item in PlantCatalog.Items.Where(x => (filter == "All categories" || x.Category == filter) &&
                (query.Length == 0 || x.CommonName.IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0 || x.ScientificName.IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0))
                .OrderBy(x => x.Category).ThenBy(x => x.CommonName)) list.Items.Add(item);
        }

        private void LoadSelected()
        {
            PlantCatalogItem item = list.SelectedItem as PlantCatalogItem;
            if (item == null) return;
            common.Text = item.CommonName; scientific.Text = item.ScientificName;
            category.SelectedItem = item.Category; type.SelectedItem = item.Type;
            height.Text = item.Height.ToString(CultureInfo.InvariantCulture);
            spread.Text = item.Spread.ToString(CultureInfo.InvariantCulture); trunk.Text = item.TrunkDiameter.ToString(CultureInfo.InvariantCulture);
        }

        private bool ReadFields(out double h, out double s, out double t)
        {
            h = 0; s = 0; t = 0;
            if (String.IsNullOrWhiteSpace(common.Text) || String.IsNullOrWhiteSpace(scientific.Text) ||
                category.SelectedItem == null || type.SelectedItem == null ||
                !double.TryParse(height.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out h) || h <= 0 ||
                !double.TryParse(spread.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out s) || s <= 0 ||
                !double.TryParse(trunk.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out t) || t < 0)
            { MessageBox.Show("Enter valid plant data."); return false; }
            return true;
        }

        private void AddNew()
        {
            double h, s, t;
            if (!ReadFields(out h, out s, out t)) return;
            if (list.SelectedItem != null && MessageBox.Show("A plant is selected. Add these values as a new record anyway?", "Open Landscape FX", MessageBoxButtons.YesNo) != DialogResult.Yes) return;
            PlantCatalogItem added = new PlantCatalogItem(common.Text.Trim(), scientific.Text.Trim(), category.Text.Trim(), type.Text.Trim(), h, s, t);
            added.Code = "CUS";
            PlantCatalog.Items.Add(added);
            PlantCatalogStore.Save(); ReloadList();
        }

        private void UpdateSelected()
        {
            PlantCatalogItem selected = list.SelectedItem as PlantCatalogItem;
            if (selected == null) { MessageBox.Show("Select a plant record to update."); return; }
            double h, s, t;
            if (!ReadFields(out h, out s, out t)) return;
            string preservedCode = selected.Code;
            PlantCatalog.Items.Remove(selected);
            PlantCatalogItem added = new PlantCatalogItem(common.Text.Trim(), scientific.Text.Trim(), category.Text.Trim(), type.Text.Trim(), h, s, t);
            CopyCatalogMetadata(selected, added);
            added.Code = String.IsNullOrWhiteSpace(preservedCode) ? "CUS" : preservedCode;
            PlantCatalog.Items.Add(added);
            PlantCatalogStore.Save(); ReloadList();
        }

        private void DeleteSelected()
        {
            PlantCatalogItem selected = list.SelectedItem as PlantCatalogItem;
            if (selected == null) return;
            PlantCatalog.Items.Remove(selected); PlantCatalogStore.Save(); ReloadList();
        }

        private void DuplicateSelected()
        {
            PlantCatalogItem selected = list.SelectedItem as PlantCatalogItem;
            if (selected == null) { MessageBox.Show("Select a plant record to duplicate."); return; }
            PlantCatalogItem copy = new PlantCatalogItem(selected.CommonName + " Copy", selected.ScientificName,
                selected.Category, selected.Type, selected.Height, selected.Spread, selected.TrunkDiameter);
            CopyCatalogMetadata(selected, copy);
            copy.Code = "CUS"; PlantCatalog.Items.Add(copy); PlantCatalogStore.Save(); ReloadList();
        }

        private void ImportCsv()
        {
            using (OpenFileDialog dialog = new OpenFileDialog { Filter = "CSV files|*.csv|All files|*.*" })
            {
                if (dialog.ShowDialog() != DialogResult.OK) return;
                int imported = 0;
                foreach (string line in File.ReadAllLines(dialog.FileName))
                {
                    string[] fields = ParseCsvLine(line); if (fields.Length < 8 || fields[0] == "CommonName") continue;
                    double h, s, t;
                    if (!double.TryParse(fields[5], NumberStyles.Float, CultureInfo.InvariantCulture, out h) ||
                        !double.TryParse(fields[6], NumberStyles.Float, CultureInfo.InvariantCulture, out s) ||
                        !double.TryParse(fields[7], NumberStyles.Float, CultureInfo.InvariantCulture, out t)) continue;
                    PlantCatalogItem item = new PlantCatalogItem(fields[0], fields[1], fields[2], fields[3], h, s, t);
                    item.Code = String.IsNullOrWhiteSpace(fields[4]) ? "CUS" : fields[4]; PlantCatalog.Items.Add(item); imported++;
                }
                PlantCatalogStore.Save(); ReloadList(); MessageBox.Show("Imported " + imported + " plant records.");
            }
        }

        private void ExportCsv()
        {
            using (SaveFileDialog dialog = new SaveFileDialog { Filter = "CSV files|*.csv", FileName = "plants.csv" })
            {
                if (dialog.ShowDialog() != DialogResult.OK) return;
                using (StreamWriter writer = new StreamWriter(dialog.FileName))
                {
                    writer.WriteLine("CommonName,ScientificName,Category,Type,Code,Height,Spread,TrunkDiameter");
                    foreach (PlantCatalogItem item in PlantCatalog.Items)
                        writer.WriteLine(String.Join(",", new[] { CsvEscape(item.CommonName), CsvEscape(item.ScientificName), CsvEscape(item.Category), CsvEscape(item.Type), CsvEscape(item.Code),
                            item.Height.ToString(CultureInfo.InvariantCulture), item.Spread.ToString(CultureInfo.InvariantCulture), item.TrunkDiameter.ToString(CultureInfo.InvariantCulture) }));
                }
                MessageBox.Show("Exported plant catalog to:\n" + dialog.FileName);
            }
        }

        private static void CopyCatalogMetadata(PlantCatalogItem source, PlantCatalogItem target)
        {
            target.WaterRequirement = source.WaterRequirement; target.SunRequirement = source.SunRequirement;
            target.Maintenance = source.Maintenance; target.Notes = source.Notes;
            target.SymbolName = source.SymbolName; target.SymbolVersion = source.SymbolVersion;
        }

        private static string CsvEscape(string value)
        {
            value = value ?? string.Empty;
            return "\"" + value.Replace("\"", "\"\"") + "\"";
        }

        private static string[] ParseCsvLine(string line)
        {
            List<string> fields = new List<string>(); string current = string.Empty; bool quoted = false;
            for (int i = 0; i < line.Length; i++)
            {
                char c = line[i];
                if (c == '\"')
                {
                    if (quoted && i + 1 < line.Length && line[i + 1] == '\"') { current += '\"'; i++; }
                    else quoted = !quoted;
                }
                else if (c == ',' && !quoted) { fields.Add(current); current = string.Empty; }
                else current += c;
            }
            fields.Add(current); return fields.ToArray();
        }

        private void ResetToDefault()
        {
            if (MessageBox.Show("Reset the external catalog to the built-in catalog? AutoCAD will reload it on the next start.",
                "Open Landscape FX", MessageBoxButtons.YesNo) != DialogResult.Yes) return;
            if (File.Exists(PlantCatalogStore.FilePath)) File.Delete(PlantCatalogStore.FilePath);
            MessageBox.Show("Default catalog will be restored after restarting AutoCAD.");
        }
    }
}
