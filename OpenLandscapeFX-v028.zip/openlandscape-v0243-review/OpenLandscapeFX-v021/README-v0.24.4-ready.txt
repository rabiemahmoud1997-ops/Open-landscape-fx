Open Landscape FX v0.24.4 — continuation of v0.24.3

This build continues from the uploaded v0.24.3 source and keeps its existing features.

Fixes:
- OLFUPDATE now rebuilds all schedule tables from the current OLF plant XData.
- Replaced plants move to the new category/code in the schedule instead of remaining in the old row.
- New categories automatically receive a new schedule table.
- Removed categories disappear from rebuilt schedules when no plants remain.
- Existing schedule table insertion positions are preserved where possible.
- If no schedule exists, OLFUPDATE asks for an insertion point.
- The old All/Select-safe label behavior remains.
- Removed the Existing keyword from OLFLABELPLANTS. The prompt is now only All/Select.

New area workflow:
OLFPLACEAREA asks for:
- Select: select a closed Polyline area.
- PickInside: pick a point inside a closed Polyline; the command finds the containing area.
Then it asks for the plant and horizontal/vertical spacing and distributes plants inside the area.

OLFPLACEBOUNDARY remains available for compatibility.

Plant Data Manager:
- Category is now a real list: Palm, Large Tree, Small Tree, Groundcover, Large Shrub, Small Shrub, Cactus.
- Type is a real list: Tree, Shrub, Groundcover, Grass.
- The selected category is stored in plants.json and is used by Plant Manager and schedules.

Commands include:
OLF, OLFUPDATE, OLFPLACEAREA, OLFPLACEBOUNDARY, OLFLABELPLANTS,
OLFPLANTDATA, OLFPLANTSCHEDULE, OLFEDITPLANT, OLFREPLACEPLANT,
OLFDELETEPLANT, OLFSETTINGS, OLFSETUPLAYERS.

Close AutoCAD before NETLOADing OpenLandscapeFx-v0.24.4.dll.
