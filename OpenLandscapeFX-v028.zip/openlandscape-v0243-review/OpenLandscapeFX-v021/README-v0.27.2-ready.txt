Open Landscape FX v0.27.2 — two-column navigation UI.

The OLF command now opens a fixed two-column interface. The left column always contains the main categories: Add Plants, Modify, Labels & Schedules, Project & Data, and Reports & Checks. The selected category is highlighted in blue. The right column immediately changes to show only the commands belonging to the selected category, visually connected to the active category panel.

Add Plants contains Plant Manager, Place Area, Plant Path, Plant Row, and Area Preview. Modify contains Replace Plant and Delete Plant. Labels & Schedules contains Label Plants, Plant Schedule, and Update Drawing. Project & Data contains Plant Data Manager, Project Settings, Setup Layers, and New Project. Reports & Checks contains Verify Plants, Plant Report, Plant Legend, and Quick Takeoff CSV.

Clicking another category updates the right column instantly; there is no Back screen. This matches the requested navigation concept from the supplied sketch.

Close AutoCAD before NETLOADing OpenLandscapeFx-v0.27.2.dll, then run OLF.
