Open Landscape FX v0.26.0 — Area Distribution Pro.

OLFPLACEAREA now supports the following workflow. Select Select or PickInside, choose the plant, enter horizontal and vertical spacing, then choose Grid or Staggered. Enter a boundary margin and a row rotation in degrees. Grid places regular rows; Staggered offsets alternate rows by half the horizontal spacing. Rotation changes the direction of the distribution grid around the area center. Margin prevents candidate points from being placed too close to the boundary.

The command also evaluates the distance between accepted plant centers and applies a per-plant scale when the spread would overlap nearby centers. It reports the number placed, the number scaled, the selected pattern, and the margin in the AutoCAD command line.

OLFPLACEBOUNDARY remains available as a legacy command. Plant Row, labels, schedules, reports, legend, and Quick Takeoff remain available from the categorized OLF interface.

Close AutoCAD before NETLOADing OpenLandscapeFx-v0.26.0.dll, then run OLF > Add Plants > Place Area.
