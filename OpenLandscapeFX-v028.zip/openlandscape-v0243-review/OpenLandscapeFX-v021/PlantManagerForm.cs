using System;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace OpenLandscapeFx
{
    public class PlantManagerForm : Form
    {
        private readonly ComboBox categoryBox;
        private readonly ComboBox catalogBox;
        private readonly TextBox nameBox;
        private readonly Label scientificLabel;
        private readonly Label typeLabelValue;
        private readonly TextBox heightBox;
        private readonly TextBox spreadBox;
        private readonly TextBox trunkBox;
        private readonly Button placeButton;
        private readonly Button cancelButton;

        public string PlantName { get; private set; }
        public string PlantType { get; private set; }
        public string PlantCategory { get; private set; }
        public string PlantCode { get; private set; }
        public double PlantHeight { get; private set; }
        public double PlantSpread { get; private set; }
        public double PlantTrunkDiameter { get; private set; }

        public PlantManagerForm()
        {
            Text = "Open Landscape FX - Plant Manager";
            Width = 620; Height = 430;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false; MinimizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;

            Controls.Add(new Label { Text = "Plant category:", Left = 18, Top = 18, Width = 125 });
            categoryBox = new ComboBox { Left = 155, Top = 14, Width = 420, DropDownStyle = ComboBoxStyle.DropDownList };
            categoryBox.Items.AddRange(PlantCatalog.Categories);
            categoryBox.SelectedIndexChanged += CategoryBox_SelectedIndexChanged;
            Controls.Add(categoryBox);

            Controls.Add(new Label { Text = "Plant:", Left = 18, Top = 56, Width = 125 });
            catalogBox = new ComboBox { Left = 155, Top = 52, Width = 420, DropDownStyle = ComboBoxStyle.DropDownList };
            catalogBox.SelectedIndexChanged += CatalogBox_SelectedIndexChanged;
            Controls.Add(catalogBox);

            Controls.Add(new Label { Text = "Scientific name:", Left = 18, Top = 94, Width = 125 });
            scientificLabel = new Label { Left = 155, Top = 94, Width = 420, ForeColor = Color.DarkGreen };
            Controls.Add(scientificLabel);

            Controls.Add(new Label { Text = "Drawing name:", Left = 18, Top = 132, Width = 125 });
            nameBox = new TextBox { Left = 155, Top = 128, Width = 420 };
            Controls.Add(nameBox);

            Controls.Add(new Label { Text = "Block category:", Left = 18, Top = 170, Width = 125 });
            typeLabelValue = new Label { Left = 155, Top = 170, Width = 200, ForeColor = Color.DarkBlue };
            Controls.Add(typeLabelValue);

            Controls.Add(new Label { Text = "Description", Left = 18, Top = 205, Width = 125, Font = new Font(DefaultFont, FontStyle.Bold) });
            Controls.Add(new Label { Text = "Height:", Left = 155, Top = 205, Width = 55 });
            heightBox = new TextBox { Left = 210, Top = 201, Width = 75 };
            Controls.Add(heightBox);
            Controls.Add(new Label { Text = "Spread:", Left = 305, Top = 205, Width = 55 });
            spreadBox = new TextBox { Left = 360, Top = 201, Width = 75 };
            Controls.Add(spreadBox);
            Controls.Add(new Label { Text = "Trunk:", Left = 455, Top = 205, Width = 50 });
            trunkBox = new TextBox { Left = 505, Top = 201, Width = 70 };
            Controls.Add(trunkBox);
            Controls.Add(new Label { Text = "User-editable values; drawing units", Left = 155, Top = 235, Width = 300, ForeColor = Color.Gray });

            placeButton = new Button { Text = "Choose plant", Left = 375, Top = 330, Width = 125, Height = 32 };
            cancelButton = new Button { Text = "Cancel", Left = 510, Top = 330, Width = 65, Height = 32 };
            placeButton.Click += PlaceButton_Click;
            cancelButton.Click += delegate { DialogResult = DialogResult.Cancel; Close(); };
            Controls.Add(placeButton); Controls.Add(cancelButton);
            AcceptButton = placeButton; CancelButton = cancelButton;
            if (categoryBox.Items.Count > 0) categoryBox.SelectedIndex = 0;
        }

        private void CategoryBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            string category = categoryBox.SelectedItem as string;
            catalogBox.Items.Clear();
            foreach (PlantCatalogItem item in PlantCatalog.Items.Where(x => x.Category == category)) catalogBox.Items.Add(item);
            if (catalogBox.Items.Count > 0) catalogBox.SelectedIndex = 0;
        }

        private void CatalogBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            PlantCatalogItem item = catalogBox.SelectedItem as PlantCatalogItem;
            if (item == null) return;
            nameBox.Text = item.CommonName;
            scientificLabel.Text = item.ScientificName;
            typeLabelValue.Text = item.Type;
            heightBox.Text = item.Height.ToString("0.##", CultureInfo.InvariantCulture);
            spreadBox.Text = item.Spread.ToString("0.##", CultureInfo.InvariantCulture);
            trunkBox.Text = item.TrunkDiameter.ToString("0.##", CultureInfo.InvariantCulture);
        }

        private void PlaceButton_Click(object sender, EventArgs e)
        {
            PlantCatalogItem item = catalogBox.SelectedItem as PlantCatalogItem;
            double height, spread, trunk;
            if (item == null || String.IsNullOrWhiteSpace(nameBox.Text) ||
                !double.TryParse(heightBox.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out height) || height <= 0 ||
                !double.TryParse(spreadBox.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out spread) || spread <= 0 ||
                !double.TryParse(trunkBox.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out trunk) || trunk < 0)
            {
                MessageBox.Show("Choose a plant and enter valid positive description values.", "Open Landscape FX");
                return;
            }
            PlantName = nameBox.Text.Trim(); PlantType = item.Type; PlantCategory = item.Category; PlantCode = item.Code;
            PlantHeight = height; PlantSpread = spread; PlantTrunkDiameter = trunk;
            DialogResult = DialogResult.OK; Close();
        }
    }
}
