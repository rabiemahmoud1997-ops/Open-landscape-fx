Open Landscape FX v0.25.0 adds two production reporting tools.

OLFPLANTLEGEND asks for an insertion point and creates plant-legend schedule tables from the plants currently in the drawing. It groups the legend by category and uses the same centered schedule format and plant symbols already used by the project.

OLFQUICKTAKEOFF asks for a CSV save location and exports PlantCode,Quantity for every OLF plant block currently in model space. The command does not alter the drawing and can be used for quantity takeoff or spreadsheet review.

Both commands are available from OLF > Reports & Checks. Existing commands and the v0.24.6 categorized interface remain unchanged.

Close AutoCAD before NETLOADing OpenLandscapeFx-v0.25.0.dll, then run OLF.
