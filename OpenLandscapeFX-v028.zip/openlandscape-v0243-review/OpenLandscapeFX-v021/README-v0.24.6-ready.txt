Open Landscape FX v0.24.6 continues the user's v0.24.3 source line.

The OLF window is now organized as a main menu with category buttons. Add Plants opens Plant Manager, Place Area, and Plant Row. Modify opens Replace Plant and Delete Plant. Labels & Schedules opens Label Plants, Plant Schedule, and Update Drawing. Project & Data opens Plant Data Manager, Project Settings, Setup Layers, and New Project. Reports & Checks opens Verify Plants and the new Plant Report command.

Edit Plant is intentionally hidden from the OLF interface because it is redundant with Replace Plant. The OLFEDITPLANT command remains in the DLL for compatibility and is not removed from the source.

The new OLFPLANTREPORT command prints total plant blocks and counts grouped by category and plant name in the AutoCAD command line. It does not modify the drawing.

Existing behavior is preserved: OLFPLACEBOUNDARY remains available as a legacy command, while Place Area is the visible replacement. Update, Replace, and Edit update existing linked leaders only and do not create leaders for unlabeled plants.

To install, close AutoCAD, run NETLOAD, and select OpenLandscapeFx-v0.24.6.dll. Then run OLF.
