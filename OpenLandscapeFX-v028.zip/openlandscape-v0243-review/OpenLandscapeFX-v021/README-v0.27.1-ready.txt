Open Landscape FX v0.27.1 — Plant Path and distribution accuracy.

OLFPLANTROW now preserves the exact spacing entered by the user. It places the first plant at the first picked point and each following plant at the exact spacing along the picked direction. The final remainder is intentionally not filled because adding it would violate the selected spacing.

OLFPLANTPATH distributes individual plant blocks along a selected Polyline. The workflow is: select the path, pick the start point, pick the end point, enter exact spacing, enter offset from the path, choose Rotation Follow or Fixed, choose the plant, and the command places plants at equal path-distance intervals. Follow rotates each block to the local tangent direction. Fixed keeps a constant user-entered rotation. Offset is measured perpendicular to the local path tangent.

OLFPLACEAREA now asks for a distribution start point. Press Enter to use the area center. It asks for angle source: Number, Mouse, or Entity. Mouse lets the user pick a direction on the drawing; Entity reads the angle from a selected Line or the first segment of a Polyline. It then asks for Grid/Staggered and boundary margin. The Area Preview command remains available and estimates locations without placing plants.

The new Plant Path command is available from OLF > Add Plants > Plant Path.

Close AutoCAD before NETLOADing OpenLandscapeFx-v0.27.1.dll, then run OLF.
