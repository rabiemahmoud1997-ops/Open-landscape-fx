using System;
using System.Globalization;
using System.Windows.Forms;

namespace OpenLandscapeFx
{
    public class ProjectSettingsForm : Form
    {
        private readonly TextBox textHeight, arrowSize, offsetX, offsetY, landingGap, dogleg;
        private readonly TextBox plantLayer, labelLayer, scheduleLayer, boundaryLayer;
        private readonly OLFProjectSettings settings;

        public ProjectSettingsForm(OLFProjectSettings value)
        {
            settings = value;
            Text = "Open Landscape FX - Project Settings";
            Width = 600; Height = 500; StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false;
            textHeight = Field("Label text height", 20, settings.TextHeight.ToString(CultureInfo.InvariantCulture));
            arrowSize = Field("Arrow size", 55, settings.ArrowSize.ToString(CultureInfo.InvariantCulture));
            offsetX = Field("Leader offset X", 90, settings.LeaderOffsetX.ToString(CultureInfo.InvariantCulture));
            offsetY = Field("Leader offset Y", 125, settings.LeaderOffsetY.ToString(CultureInfo.InvariantCulture));
            landingGap = Field("Landing gap", 160, settings.LandingGap.ToString(CultureInfo.InvariantCulture));
            dogleg = Field("Dogleg length", 195, settings.DoglegLength.ToString(CultureInfo.InvariantCulture));
            plantLayer = Field("Plant layer", 245, settings.PlantLayer);
            labelLayer = Field("Label layer", 280, settings.LabelLayer);
            scheduleLayer = Field("Schedule layer", 315, settings.ScheduleLayer);
            boundaryLayer = Field("Boundary layer", 350, settings.BoundaryLayer);
            Button reset = new Button { Text = "Reset Defaults", Left = 175, Top = 410, Width = 125, Height = 32 };
            Button save = new Button { Text = "Save", Left = 370, Top = 410, Width = 95, Height = 32 };
            Button cancel = new Button { Text = "Cancel", Left = 475, Top = 410, Width = 95, Height = 32 };
            reset.Click += delegate { ResetFields(); };
            save.Click += delegate { if (Read()) { ProjectSettingsStore.Save(settings); DialogResult = DialogResult.OK; Close(); } };
            cancel.Click += delegate { DialogResult = DialogResult.Cancel; Close(); };
            Controls.Add(reset); Controls.Add(save); Controls.Add(cancel); AcceptButton = save; CancelButton = cancel;
        }

        private void ResetFields()
        {
            OLFProjectSettings defaults = new OLFProjectSettings();
            textHeight.Text = defaults.TextHeight.ToString(CultureInfo.InvariantCulture);
            arrowSize.Text = defaults.ArrowSize.ToString(CultureInfo.InvariantCulture);
            offsetX.Text = defaults.LeaderOffsetX.ToString(CultureInfo.InvariantCulture);
            offsetY.Text = defaults.LeaderOffsetY.ToString(CultureInfo.InvariantCulture);
            landingGap.Text = defaults.LandingGap.ToString(CultureInfo.InvariantCulture);
            dogleg.Text = defaults.DoglegLength.ToString(CultureInfo.InvariantCulture);
            plantLayer.Text = defaults.PlantLayer; labelLayer.Text = defaults.LabelLayer;
            scheduleLayer.Text = defaults.ScheduleLayer; boundaryLayer.Text = defaults.BoundaryLayer;
        }

        private TextBox Field(string caption, int top, string value)
        {
            Controls.Add(new Label { Text = caption + ":", Left = 20, Top = top + 3, Width = 145 });
            TextBox box = new TextBox { Left = 175, Top = top, Width = 355, Text = value };
            Controls.Add(box); return box;
        }

        private bool Read()
        {
            double value;
            if (!double.TryParse(textHeight.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out value) || value <= 0) return Invalid(); settings.TextHeight = value;
            if (!double.TryParse(arrowSize.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out value) || value <= 0) return Invalid(); settings.ArrowSize = value;
            if (!double.TryParse(offsetX.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out value) || value <= 0) return Invalid(); settings.LeaderOffsetX = value;
            if (!double.TryParse(offsetY.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out value) || value <= 0) return Invalid(); settings.LeaderOffsetY = value;
            if (!double.TryParse(landingGap.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out value) || value < 0) return Invalid(); settings.LandingGap = value;
            if (!double.TryParse(dogleg.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out value) || value < 0) return Invalid(); settings.DoglegLength = value;
            settings.PlantLayer = plantLayer.Text.Trim(); settings.LabelLayer = labelLayer.Text.Trim(); settings.ScheduleLayer = scheduleLayer.Text.Trim(); settings.BoundaryLayer = boundaryLayer.Text.Trim(); settings.Normalize(); return true;
        }

        private bool Invalid() { MessageBox.Show("Enter valid settings values.", "Open Landscape FX"); return false; }
    }
}
