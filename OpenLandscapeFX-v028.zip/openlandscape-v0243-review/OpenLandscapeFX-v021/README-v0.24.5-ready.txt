Open Landscape FX v0.24.5 — continuation of v0.24.4

Fixes and behavior:
- OLF now shows Place Area instead of Place Boundary. OLFPLACEBOUNDARY remains available as a compatibility command.
- OLFUPDATE no longer creates new leaders. It updates only existing OLF leaders linked to plants and does not label plants that have no leader.
- OLFREPLACEPLANT and OLFEDITPLANT now update only existing linked leaders; they do not create labels for previously unlabeled plants.
- OLFUPDATE rebuilds schedule tables from current plant data, moves replacements to the correct category/code, creates missing category tables, removes empty category tables, and keeps the previous table spacing/positions. Additional tables use the original dynamic row-height spacing instead of a fixed large gap.
- OLFLABELPLANTS remains All/Select only; Existing is removed.

Data Manager:
- Category is now a real dropdown matching Plant Manager: Palm, Large Tree, Small Tree, Groundcover, Large Shrub, Small Shrub, Cactus.
- Type is now a real dropdown: Tree, Shrub, Groundcover, Grass.
- Existing search, filter, add, update, duplicate, import/export, reset, and JSON features are preserved.

New production tool:
- OLFPLANTROW places repeated plants between two picked points using a user-defined spacing.

OLF tools window now exposes all current commands, including Place Area, Plant Row, Edit Plant, Update Drawing, Data Manager, Settings, Setup Layers, and Verify Plants.

Close AutoCAD before NETLOADing OpenLandscapeFx-v0.24.5.dll.
