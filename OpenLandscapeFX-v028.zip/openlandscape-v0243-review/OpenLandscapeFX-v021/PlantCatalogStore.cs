using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;

namespace OpenLandscapeFx
{
    [DataContract]
    public class PlantDataRecord
    {
        [DataMember] public string CommonName;
        [DataMember] public string ScientificName;
        [DataMember] public string Category;
        [DataMember] public string Type;
        [DataMember] public string Code;
        [DataMember] public double Height;
        [DataMember] public double Spread;
        [DataMember] public double TrunkDiameter;
        [DataMember] public string WaterRequirement;
        [DataMember] public string SunRequirement;
        [DataMember] public string Maintenance;
        [DataMember] public string Notes;
        [DataMember] public string SymbolName;
        [DataMember] public int SymbolVersion;
    }

    public static class PlantCatalogStore
    {
        public static string FilePath
        {
            get
            {
                string folder = Path.GetDirectoryName(typeof(PlantCatalogStore).Assembly.Location);
                return Path.Combine(folder ?? Environment.CurrentDirectory, "plants.json");
            }
        }

        public static void EnsureExternalCatalog()
        {
            if (File.Exists(FilePath))
                return;
            Save();
        }

        public static void Load()
        {
            if (!File.Exists(FilePath))
                return;
            try
            {
                DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(List<PlantDataRecord>));
                using (FileStream stream = File.OpenRead(FilePath))
                {
                    List<PlantDataRecord> records = serializer.ReadObject(stream) as List<PlantDataRecord>;
                    if (records == null || records.Count == 0) return;
                    PlantCatalog.Items.Clear();
                    foreach (PlantDataRecord record in records)
                    {
                        PlantCatalogItem item = new PlantCatalogItem(record.CommonName, record.ScientificName,
                            record.Category, record.Type, record.Height, record.Spread, record.TrunkDiameter);
                        item.Code = String.IsNullOrWhiteSpace(record.Code) ? "UNK" : record.Code;
                        item.WaterRequirement = String.IsNullOrWhiteSpace(record.WaterRequirement) ? "Medium" : record.WaterRequirement;
                        item.SunRequirement = String.IsNullOrWhiteSpace(record.SunRequirement) ? "Full Sun" : record.SunRequirement;
                        item.Maintenance = String.IsNullOrWhiteSpace(record.Maintenance) ? "Medium" : record.Maintenance;
                        item.Notes = record.Notes ?? string.Empty; item.SymbolName = record.SymbolName ?? string.Empty;
                        item.SymbolVersion = record.SymbolVersion <= 0 ? 1 : record.SymbolVersion;
                        PlantCatalog.Items.Add(item);
                    }
                }
            }
            catch (Exception error)
            {
                try
                {
                    string backup = FilePath + ".invalid-" + DateTime.Now.ToString("yyyyMMddHHmmss");
                    File.Copy(FilePath, backup, true);
                }
                catch { }
                System.Windows.Forms.MessageBox.Show(
                    "The external plant catalog could not be loaded. The invalid file was backed up and the built-in catalog will be used.\n\n" + error.Message,
                    "Open Landscape FX - Catalog", System.Windows.Forms.MessageBoxButtons.OK,
                    System.Windows.Forms.MessageBoxIcon.Warning);
            }
        }

        public static void Save()
        {
            List<PlantDataRecord> records = new List<PlantDataRecord>();
            foreach (PlantCatalogItem item in PlantCatalog.Items)
                records.Add(new PlantDataRecord {
                    CommonName = item.CommonName, ScientificName = item.ScientificName,
                    Category = item.Category, Type = item.Type, Code = item.Code,
                    Height = item.Height, Spread = item.Spread, TrunkDiameter = item.TrunkDiameter,
                    WaterRequirement = item.WaterRequirement, SunRequirement = item.SunRequirement,
                    Maintenance = item.Maintenance, Notes = item.Notes, SymbolName = item.SymbolName,
                    SymbolVersion = item.SymbolVersion
                });
            DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(List<PlantDataRecord>));
            using (FileStream stream = File.Create(FilePath))
                serializer.WriteObject(stream, records);
        }
    }
}
