Open Landscape FX - AutoCAD 2021 v0.7.1

Close AutoCAD and load this DLL only. Start a new drawing for a clean test.

OLFPLACEAREA now asks for two independent spacings:
1. Horizontal spacing
2. Vertical spacing
Then it asks for the two rectangle corners.

Other commands:
OLFABOUT, OLFNEWPROJECT, OLFPLANTMANAGER, OLFLABELPLANTS, OLFPLANTSCHEDULE
