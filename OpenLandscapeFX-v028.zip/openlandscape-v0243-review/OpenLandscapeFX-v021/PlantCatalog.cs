using System;
using System.Collections.Generic;

namespace OpenLandscapeFx
{
    public class PlantCatalogItem
    {
        public string CommonName { get; private set; }
        public string ScientificName { get; private set; }
        public string Category { get; private set; }
        public string Type { get; private set; }
        public string Code { get; internal set; }
        public double Height { get; private set; }
        public double Spread { get; private set; }
        public double TrunkDiameter { get; private set; }
        public string WaterRequirement { get; set; }
        public string SunRequirement { get; set; }
        public string Maintenance { get; set; }
        public string Notes { get; set; }
        public string SymbolName { get; set; }
        public int SymbolVersion { get; set; }

        public PlantCatalogItem(string commonName, string scientificName, string category, string type)
        {
            CommonName = commonName;
            ScientificName = scientificName;
            Category = category;
            Type = type;
            Height = DefaultHeight(category);
            Spread = DefaultSpread(category);
            TrunkDiameter = DefaultTrunk(category);
            WaterRequirement = "Medium";
            SunRequirement = "Full Sun";
            Maintenance = "Medium";
            Notes = string.Empty;
            SymbolName = string.Empty;
            SymbolVersion = 1;
        }

        public PlantCatalogItem(string commonName, string scientificName, string category, string type,
            double height, double spread, double trunkDiameter)
            : this(commonName, scientificName, category, type)
        {
            Height = height;
            Spread = spread;
            TrunkDiameter = trunkDiameter;
        }

        private static double DefaultHeight(string category)
        {
            if (category == "Palm") return 8.0;
            if (category == "Large Tree") return 8.0;
            if (category == "Small Tree") return 4.0;
            if (category == "Large Shrub") return 2.5;
            if (category == "Small Shrub") return 1.0;
            if (category == "Groundcover") return 0.25;
            return 1.2;
        }

        private static double DefaultSpread(string category)
        {
            if (category == "Palm" || category == "Large Tree") return 5.0;
            if (category == "Small Tree") return 3.0;
            if (category == "Large Shrub") return 2.0;
            if (category == "Small Shrub") return 1.0;
            if (category == "Groundcover") return 0.5;
            return 1.0;
        }

        private static double DefaultTrunk(string category)
        {
            if (category == "Palm" || category == "Large Tree") return 0.30;
            if (category == "Small Tree") return 0.18;
            return 0.05;
        }

        public override string ToString()
        {
            return CommonName + " — " + ScientificName;
        }
    }

    public static class PlantCatalog
    {
        public static readonly string[] Categories =
        {
            "Palm",
            "Large Tree",
            "Small Tree",
            "Groundcover",
            "Large Shrub",
            "Small Shrub",
            "Cactus"
        };

        public static List<PlantCatalogItem> Items = new List<PlantCatalogItem>
        {
            // Palms
            new PlantCatalogItem("Date Palm", "Phoenix dactylifera", "Palm", "Tree"),
            new PlantCatalogItem("Canary Island Date Palm", "Phoenix canariensis", "Palm", "Tree"),
            new PlantCatalogItem("Washingtonia Palm", "Washingtonia robusta", "Palm", "Tree"),
            new PlantCatalogItem("Mexican Fan Palm", "Washingtonia filifera", "Palm", "Tree"),
            new PlantCatalogItem("Queen Palm", "Syagrus romanzoffiana", "Palm", "Tree"),
            new PlantCatalogItem("Pygmy Date Palm", "Phoenix roebelenii", "Palm", "Tree"),
            new PlantCatalogItem("Sabal Palm", "Sabal palmetto", "Palm", "Tree"),
            new PlantCatalogItem("Bismarck Palm", "Bismarckia nobilis", "Palm", "Tree"),
            new PlantCatalogItem("Coconut Palm", "Cocos nucifera", "Palm", "Tree"),
            new PlantCatalogItem("Areca Palm", "Dypsis lutescens", "Palm", "Tree"),

            // Trees
            new PlantCatalogItem("Ghaf Tree", "Acacia tortilis", "Large Tree", "Tree"),
            new PlantCatalogItem("Samar Tree", "Vachellia nilotica", "Large Tree", "Tree"),
            new PlantCatalogItem("Neem", "Azadirachta indica", "Large Tree", "Tree"),
            new PlantCatalogItem("Olive", "Olea europaea", "Large Tree", "Tree"),
            new PlantCatalogItem("Jacaranda", "Jacaranda mimosifolia", "Large Tree", "Tree"),
            new PlantCatalogItem("Royal Poinciana", "Delonix regia", "Large Tree", "Tree"),
            new PlantCatalogItem("Tabebuia", "Handroanthus spp.", "Large Tree", "Tree"),
            new PlantCatalogItem("Indian Almond", "Terminalia catappa", "Large Tree", "Tree"),
            new PlantCatalogItem("Ficus", "Ficus nitida", "Large Tree", "Tree"),
            new PlantCatalogItem("Frangipani", "Plumeria alba", "Large Tree", "Tree"),
            new PlantCatalogItem("Moringa", "Moringa oleifera", "Large Tree", "Tree"),
            new PlantCatalogItem("Ghaf", "Prosopis cineraria", "Large Tree", "Tree"),
            new PlantCatalogItem("Carob", "Ceratonia siliqua", "Large Tree", "Tree"),
            new PlantCatalogItem("Pomegranate", "Punica granatum", "Small Tree", "Tree"),
            new PlantCatalogItem("Citrus", "Citrus spp.", "Small Tree", "Tree"),

            // Groundcovers and low planting
            new PlantCatalogItem("Wedelia", "Sphagneticola trilobata", "Groundcover", "Groundcover"),
            new PlantCatalogItem("Dwarf Morning Glory", "Evolvulus glomeratus", "Groundcover", "Groundcover"),
            new PlantCatalogItem("Vinca", "Catharanthus roseus", "Groundcover", "Groundcover"),
            new PlantCatalogItem("Lantana Groundcover", "Lantana montevidensis", "Groundcover", "Groundcover"),
            new PlantCatalogItem("Gazania", "Gazania rigens", "Groundcover", "Groundcover"),
            new PlantCatalogItem("Portulaca", "Portulaca grandiflora", "Groundcover", "Groundcover"),
            new PlantCatalogItem("Spider Plant", "Chlorophytum comosum", "Groundcover", "Groundcover"),
            new PlantCatalogItem("Ivy", "Hedera helix", "Groundcover", "Groundcover"),
            new PlantCatalogItem("Bermuda Grass", "Cynodon dactylon", "Groundcover", "Groundcover"),
            new PlantCatalogItem("Zoysia Grass", "Zoysia japonica", "Groundcover", "Groundcover"),

            // Large shrubs
            new PlantCatalogItem("Bougainvillea", "Bougainvillea spectabilis", "Large Shrub", "Shrub"),
            new PlantCatalogItem("Oleander", "Nerium oleander", "Large Shrub", "Shrub"),
            new PlantCatalogItem("Yellow Bells", "Tecoma stans", "Large Shrub", "Shrub"),
            new PlantCatalogItem("Hibiscus", "Hibiscus rosa-sinensis", "Large Shrub", "Shrub"),
            new PlantCatalogItem("Cape Honeysuckle", "Tecomaria capensis", "Large Shrub", "Shrub"),
            new PlantCatalogItem("Clerodendrum", "Clerodendrum inerme", "Large Shrub", "Shrub"),
            new PlantCatalogItem("Bird of Paradise", "Strelitzia reginae", "Large Shrub", "Shrub"),
            new PlantCatalogItem("Orange Jasmine", "Murraya paniculata", "Large Shrub", "Shrub"),
            new PlantCatalogItem("Crown of Thorns", "Euphorbia milii", "Large Shrub", "Shrub"),

            // Small shrubs
            new PlantCatalogItem("Lantana", "Lantana camara", "Small Shrub", "Shrub"),
            new PlantCatalogItem("Lavender", "Lavandula angustifolia", "Small Shrub", "Shrub"),
            new PlantCatalogItem("Rose", "Rosa spp.", "Small Shrub", "Shrub"),
            new PlantCatalogItem("Rosemary", "Salvia rosmarinus", "Small Shrub", "Shrub"),
            new PlantCatalogItem("Duranta", "Duranta erecta", "Small Shrub", "Shrub"),
            new PlantCatalogItem("Pentas", "Pentas lanceolata", "Small Shrub", "Shrub"),
            new PlantCatalogItem("Ixora", "Ixora coccinea", "Small Shrub", "Shrub"),
            new PlantCatalogItem("Hamelia", "Hamelia patens", "Small Shrub", "Shrub"),
            new PlantCatalogItem("Plumbago", "Plumbago auriculata", "Small Shrub", "Shrub"),
            new PlantCatalogItem("Teucrium", "Teucrium fruticans", "Small Shrub", "Shrub"),

            // Cacti and succulents
            new PlantCatalogItem("Aloe Vera", "Aloe vera", "Cactus", "Shrub"),
            new PlantCatalogItem("Agave", "Agave americana", "Cactus", "Shrub"),
            new PlantCatalogItem("Golden Barrel Cactus", "Echinocactus grusonii", "Cactus", "Shrub"),
            new PlantCatalogItem("Organ Pipe Cactus", "Stenocereus thurberi", "Cactus", "Shrub"),
            new PlantCatalogItem("Prickly Pear", "Opuntia ficus-indica", "Cactus", "Shrub"),
            new PlantCatalogItem("Century Plant", "Agave attenuata", "Cactus", "Shrub"),
            new PlantCatalogItem("Euphorbia Cactus", "Euphorbia ingens", "Cactus", "Shrub"),
            new PlantCatalogItem("Sansevieria", "Dracaena trifasciata", "Cactus", "Shrub")
        };

        static PlantCatalog()
        {
            HashSet<string> used = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (PlantCatalogItem item in Items)
            {
                string baseCode = MakeBaseCode(item.ScientificName);
                string code = baseCode;
                int suffix = 1;
                while (!used.Add(code))
                {
                    code = baseCode.Substring(0, 2) + (char)('A' + suffix++);
                }
                item.Code = code;
            }
            PlantCatalogStore.Load();
            PlantCatalogStore.EnsureExternalCatalog();
        }

        private static string MakeBaseCode(string scientificName)
        {
            string letters = string.Empty;
            foreach (string word in scientificName.Split(new[] { ' ', '.', '-' }, StringSplitOptions.RemoveEmptyEntries))
                if (word.Length > 0 && char.IsLetter(word[0])) letters += char.ToUpperInvariant(word[0]);
            foreach (char c in scientificName.ToUpperInvariant())
                if (char.IsLetter(c) && letters.IndexOf(c) < 0) letters += c;
            while (letters.Length < 3) letters += "X";
            return letters.Substring(0, 3);
        }
    }
}
